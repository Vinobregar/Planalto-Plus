import React, { useDeferredValue, useEffect, useMemo, useRef, useState } from 'react';
import {
  BookMarked,
  Check,
  CheckCheck,
  ChevronDown,
  ChevronUp,
  Copy,
  ExternalLink,
  Eye,
  FileText,
  Headphones,
  HelpCircle,
  Library,
  MessageSquare,
  PanelLeftOpen,
  PanelRightOpen,
  Pause,
  Play,
  Quote,
  Scale,
  Search,
  Sparkles,
  Type,
  X,
} from 'lucide-react';
import {
  AIConfig,
  AppearanceSettings,
  ArticleAnnotation,
  ArticleBlock,
  AuthSession,
  ChatMessage,
  EditalArticleMatch,
  FlashcardGenerationParams,
  FlashcardItem,
  HighlightTag,
  LegislationDocument,
  OabIncidenceItem,
  QuizGenerationParams,
  QuizQuestion,
  StudyProgressEntry,
} from '../types/legislation';
import {
  DEFAULT_AI_CONFIG,
  DEFAULT_APPEARANCE,
  DEFAULT_HIGHLIGHT_TAGS,
  RELEVANT_BRAZILIAN_LAWS,
  computeProportionalAppearance,
  formatLawAbntCitation,
  getCommonLawName,
  loadAIConfig,
  loadAppearanceSettings,
  loadHighlightTags,
  loadLawAnnotations,
  resolveHighlightTag,
  saveAIConfig,
  saveAppearanceSettings,
  saveHighlightTags,
  saveLawAnnotations,
  saveAISessionBackup,
  loadAISessionBackup,
} from '../storage/storageService';
import {
  DEFAULT_FLASHCARD_PARAMS,
  DEFAULT_QUIZ_PARAMS,
  analyzeEditalAndSelectArticles,
  explainArticleWithAI,
  generateArticleQuizWithAI,
  generateFlashcardsWithAI,
  sendLegalChatWithAI,
  summarizeArticleJurisprudenceWithAI,
} from '../services/aiService';
import { getAICache } from '../storage/indexedDBService';
import { TocSidebar } from './TocSidebar';
import { ShortcutsModal } from './ShortcutsModal';
import { normalizeArticleNumberKey } from '../utils/crossReferenceGraph';
import {
  AppearancePopover,
  FONT_FAMILY_CSS,
  computeThemeColors,
} from './AppearancePopover';
import { getSynonymsForQuery } from '../utils/legalSynonyms';
import { parseBooleanQuery, evaluateBooleanSearch } from '../utils/booleanSearch';
import {
  ArticleItem,
  ModificationNoteBadge,
  hexToRgba,
} from './ArticleItem';
import { CadernoSubTab, RightDrawer, RightDrawerTab } from './RightDrawer';
import { buildCrossReferenceGraph } from '../utils/crossReferenceGraph';
import { CrossReferenceGraphModal } from './CrossReferenceGraphModal';
import { ProDrawerModal } from './ProDrawerModal';
import {
  getAuthSession,
  isPcdUser,
  isProUser,
  setPcdUserStatus,
} from '../services/auth.js';
import { pullLawAnnotationsFromCloud } from '../services/cloudSync.js';
import {
  playArticleAudio,
  stopArticleAudio,
  subscribeAudioPlayer,
  speakWithNativeWebSpeech,
} from '../features/audioPlayer.js';
import {
  PODCAST_SPEED_OPTIONS,
  loadOrGenerateLawPodcast,
} from '../features/lawPodcast.js';
import {
  getAutoHighlightsForCurrentLaw,
  parseEditalAndHighlight,
} from '../features/editalParser.js';
import {
  askLawQuestion,
  extractCitedArticlesFromAnswer,
} from '../features/askLaw.js';
import {
  attachStudyTrailObserver,
  loadStudyTrailProgress,
  markArticleAsRead,
} from '../features/studyTrail.js';
import { getOabIncidenceForDocument } from '../features/oabMapper.js';
import { syncVlibrasWidget } from '../features/vlibras.js';

interface PlanaltoReaderAppProps {
  doc: LegislationDocument;
  onToggleOriginalView: () => void;
}

export const PlanaltoReaderApp: React.FC<PlanaltoReaderAppProps> = ({
  doc,
  onToggleOriginalView,
}) => {
  const [appearance, setAppearance] = useState<AppearanceSettings>(() =>
    computeProportionalAppearance()
  );
  const [aiConfig, setAiConfig] = useState<AIConfig>(DEFAULT_AI_CONFIG);
  const [highlightTags, setHighlightTags] = useState<HighlightTag[]>(
    DEFAULT_HIGHLIGHT_TAGS
  );
  const [annotations, setAnnotations] = useState<
    Record<string, ArticleAnnotation>
  >({});

  const [leftSidebarOpen, setLeftSidebarOpen] = useState(true);
  const [rightDrawerOpen, setRightDrawerOpen] = useState(false);
  const [rightDrawerTab, setRightDrawerTab] = useState<RightDrawerTab>('notes');
  const [cadernoSubTab, setCadernoSubTab] = useState<CadernoSubTab>('grifos');

  // Shared search query between Sumário (left sidebar) and Centered Top Search Bar
  const [searchQuery, setSearchQuery] = useState('');
  const deferredSearchQuery = useDeferredValue(searchQuery);
  const [appliedFilterQuery, setAppliedFilterQuery] = useState<string | null>(null);
  const [searchWithSynonyms, setSearchWithSynonyms] = useState(false);

  const handleApplySearchFilter = () => {
    const q = searchQuery.trim();
    if (!q) {
      setAppliedFilterQuery(null);
      setShowTopSearchDropdown(false);
      return;
    }
    setAppliedFilterQuery(q);
    setShowTopSearchDropdown(false);

    // Desce a página até a primeira incidência do termo buscado
    const cleanQuery = q.replace(/[º°.]/g, '').trim();
    const numMatch = /^(?:art(?:igo)?\s*)?(\d+[\w-]*)$/i.exec(cleanQuery);
    let firstMatch: ArticleBlock | undefined;

    if (numMatch) {
      const target = normalizeArticleNumberKey(numMatch[1]);
      const cleanTarget = target.replace(/-/g, '');
      firstMatch = doc.articles.find((art) => {
        if (appearance.compiledMode && art.isRevoked) return false;
        const artKey = normalizeArticleNumberKey(art.number);
        const cleanArtKey = artKey.replace(/-/g, '');
        return artKey === target || cleanArtKey === cleanTarget;
      });
    } else {
      const parsed = parseBooleanQuery(q, searchWithSynonyms);
      firstMatch = doc.articles.find((art) => {
        if (appearance.compiledMode && art.isRevoked) return false;
        const fullText = `${art.number} ${art.label} ${art.caputText} ${art.subClauses.map((sc) => sc.text).join(' ')} ${annotations[art.id]?.note || ''}`;
        return evaluateBooleanSearch(fullText, parsed, searchWithSynonyms);
      });
    }

    if (firstMatch) {
      setFocusedArticleId(firstMatch.id);
      setTimeout(() => {
        scrollToElementId(firstMatch!.id);
      }, 50);
    }
  };

  // Words to highlight in the article text when a term search is performed
  const searchHighlightWords = useMemo(() => {
    const query = searchQuery.trim();
    if (!query) return [];
    // Do not highlight pure article numbers (e.g. "155", "art. 155")
    const cleanNum = query.replace(/[º°.]/g, '').trim();
    if (/^(?:art(?:igo)?\s*)?\d+[\w-]*$/i.test(cleanNum)) {
      return [];
    }
    const parsed = parseBooleanQuery(query, searchWithSynonyms);
    return parsed.highlightTerms;
  }, [searchQuery, searchWithSynonyms]);

  const activeFilteredArticleIds = useMemo(() => {
    if (!appliedFilterQuery) return null;
    const q = appliedFilterQuery.trim();
    const cleanQuery = q.replace(/[º°.]/g, '').trim();
    const numMatch = /^(?:art(?:igo)?\s*)?(\d+[\w-]*)$/i.exec(cleanQuery);
    if (numMatch) {
      const target = normalizeArticleNumberKey(numMatch[1]);
      const cleanTarget = target.replace(/-/g, '');
      const ids = new Set<string>();
      for (const art of doc.articles) {
        if (appearance.compiledMode && art.isRevoked) continue;
        const artKey = normalizeArticleNumberKey(art.number);
        const cleanArtKey = artKey.replace(/-/g, '');
        if (artKey === target || cleanArtKey === cleanTarget) {
          ids.add(art.id);
        }
      }
      return ids;
    }

    const parsed = parseBooleanQuery(q, searchWithSynonyms);
    const ids = new Set<string>();
    for (const art of doc.articles) {
      if (appearance.compiledMode && art.isRevoked) continue;
      const fullText = `${art.number} ${art.label} ${art.caputText} ${art.subClauses.map((sc) => sc.text).join(' ')} ${annotations[art.id]?.note || ''}`;
      if (evaluateBooleanSearch(fullText, parsed, searchWithSynonyms)) {
        ids.add(art.id);
      }
    }
    return ids;
  }, [appliedFilterQuery, searchWithSynonyms, doc.articles, appearance.compiledMode, annotations]);
  const [showTopSearchDropdown, setShowTopSearchDropdown] = useState(false);

  // Floating menu states
  const [showAppearancePopover, setShowAppearancePopover] = useState(false);
  const [showLawsMenu, setShowLawsMenu] = useState(false);
  const [showCrossRefModal, setShowCrossRefModal] = useState(false);
  const [crossRefModalArticle, setCrossRefModalArticle] =
    useState<ArticleBlock | null>(null);
  const [lawSearchQuery, setLawSearchQuery] = useState('');
  const [copiedAbnt, setCopiedAbnt] = useState(false);

  const [focusedArticleId, setFocusedArticleId] = useState<string | null>(
    doc.articles[0]?.id || null
  );
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [quizQuestions, setQuizQuestions] = useState<QuizQuestion[]>([]);
  const [quizParams, setQuizParams] =
    useState<QuizGenerationParams>(DEFAULT_QUIZ_PARAMS);
  const [previousQuizStatements, setPreviousQuizStatements] = useState<
    string[]
  >([]);
  const [flashcards, setFlashcards] = useState<FlashcardItem[]>([]);
  const [flashcardParams, setFlashcardParams] =
    useState<FlashcardGenerationParams>(DEFAULT_FLASHCARD_PARAMS);
  const [editalMatches, setEditalMatches] = useState<EditalArticleMatch[]>([]);
  const [isLoadingAI, setIsLoadingAI] = useState(false);
  const [aiError, setAiError] = useState<string | null>(null);

  // Camada PRO, Acessibilidade PcD, Áudio, Podcast Panorâmico, Trilha & Incidência OAB
  const [authSession, setAuthSession] = useState<AuthSession | null>(null);
  const [isPro, setIsPro] = useState(false);
  const [isPcd, setIsPcd] = useState(false);
  const [proDrawerOpen, setProDrawerOpen] = useState(false);
  const [proDrawerFeatureKey, setProDrawerFeatureKey] = useState('default');

  const [playingArticleId, setPlayingArticleId] = useState<string | null>(null);
  const [podcastOpen, setPodcastOpen] = useState(false);
  const [podcastLoading, setPodcastLoading] = useState(false);
  const [podcastData, setPodcastData] = useState<any | null>(null);
  const [podcastPlaying, setPodcastPlaying] = useState(false);
  const [podcastSpeed, setPodcastSpeed] = useState<number>(1.0);
  const [podcastProgress, setPodcastProgress] = useState<number>(0);
  const [showPodcastTranscript, setShowPodcastTranscript] = useState(false);
  const podcastAudioRef = useRef<HTMLAudioElement | null>(null);
  const podcastProgressTimerRef = useRef<number | null>(null);

  const [studyProgress, setStudyProgress] = useState<StudyProgressEntry | null>(
    null
  );
  const [oabByArticleId, setOabByArticleId] = useState<
    Record<string, OabIncidenceItem>
  >({});
  const [oabItems, setOabItems] = useState<OabIncidenceItem[]>([]);

  const handleOpenProDrawer = (featureKey = 'default') => {
    setProDrawerFeatureKey(featureKey);
    setProDrawerOpen(true);
  };

  const refreshAuthAndPermissions = async () => {
    const [session, pro, pcd] = await Promise.all([
      getAuthSession(),
      isProUser(),
      isPcdUser(),
    ]);
    setAuthSession(session);
    setIsPro(Boolean(pro));
    setIsPcd(Boolean(pcd));
  };

  
  // Jump instantaneously (without smooth animation) to next/previous article
  const handleJumpRelativeArticle = (direction: 1 | -1) => {
    const list = doc.articles.filter((a) => !appearance.compiledMode || !a.isRevoked);
    if (list.length === 0) return;

    let currentIndex = list.findIndex((a) => a.id === focusedArticleId);
    if (currentIndex === -1) {
      currentIndex = direction === 1 ? -1 : list.length;
    }

    const nextIndex = Math.max(0, Math.min(list.length - 1, currentIndex + direction));
    const target = list[nextIndex];
    if (target) {
      setFocusedArticleId(target.id);
      const el = readerScrollRef.current?.querySelector(`#${target.id}`);
      if (el) {
        // Fast instantaneous jump as requested
        el.scrollIntoView({ behavior: 'auto', block: 'start' });
      }
    }
  };

  // Global Keyboard Shortcuts (J, K, /, C, [, ], ?, Esc)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      if (
        target &&
        (target.tagName === 'INPUT' ||
          target.tagName === 'TEXTAREA' ||
          target.isContentEditable ||
          target.closest('input, textarea, [contenteditable="true"]'))
      ) {
        if (e.key === 'Escape') {
          target.blur();
        }
        return;
      }

      if (e.metaKey || e.ctrlKey || e.altKey) {
        return;
      }

      const key = e.key.toLowerCase();

      if (key === 'j') {
        e.preventDefault();
        handleJumpRelativeArticle(1);
        return;
      }

      if (key === 'k') {
        e.preventDefault();
        handleJumpRelativeArticle(-1);
        return;
      }

      if (e.key === '/') {
        e.preventDefault();
        topSearchInputRef.current?.focus();
        topSearchInputRef.current?.select();
        return;
      }

      if (key === 'c') {
        e.preventDefault();
        handleUpdateAppearance({
          ...appearance,
          compiledMode: !appearance.compiledMode,
        });
        return;
      }

      if (e.key === '[') {
        e.preventDefault();
        setLeftSidebarOpen((v) => !v);
        return;
      }

      if (e.key === ']') {
        e.preventDefault();
        setRightDrawerOpen((v) => !v);
        return;
      }

      if (e.key === '?') {
        e.preventDefault();
        setShowShortcutsModal((v) => !v);
        return;
      }

      if (e.key === 'Escape') {
        setShowShortcutsModal(false);
        setShowTopSearchDropdown(false);
        setShowAppearancePopover(false);
        setShowLawsMenu(false);
        setShowCrossRefModal(false);
        return;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [focusedArticleId, appearance, doc.articles, leftSidebarOpen, rightDrawerOpen]);

  const readerScrollRef = useRef<HTMLDivElement | null>(null);
  const lawsMenuRef = useRef<HTMLDivElement | null>(null);
  const appearanceMenuRef = useRef<HTMLDivElement | null>(null);
  const topSearchRef = useRef<HTMLDivElement | null>(null);
  const topSearchInputRef = useRef<HTMLInputElement | null>(null);
  const [showShortcutsModal, setShowShortcutsModal] = useState(false);

  const crossRefGraph = useMemo(
    () => buildCrossReferenceGraph(doc.articles, annotations),
    [doc.articles, annotations]
  );

  const commonLawName = useMemo(() => getCommonLawName(doc), [doc]);
  const abntCitation = useMemo(() => formatLawAbntCitation(doc), [doc]);

  // Map each article ID to its preceding article for "artigo anterior" links
  const previousArticleById = useMemo(() => {
    const map: Record<string, ArticleBlock | null> = {};
    for (let i = 0; i < doc.articles.length; i++) {
      map[doc.articles[i].id] = i > 0 ? doc.articles[i - 1] : null;
    }
    return map;
  }, [doc.articles]);

  // All articles in the law matching current search (compiledMode respected)
  const matchingArticles = useMemo(() => {
    const q = searchQuery.trim();
    if (!q) return [];

    // Check if query is targeting an article number (e.g. "155", "art 155", "art. 155", "artigo 155", "155º", "155-A", "155a")
    const cleanQuery = q.replace(/[º°.]/g, '').trim();
    const articleNumPattern = /^(?:art(?:igo)?\s*)?(\d+[\w-]*)$/i;
    const numMatch = articleNumPattern.exec(cleanQuery);

    if (numMatch) {
      const target = normalizeArticleNumberKey(numMatch[1]);
      const cleanTarget = target.replace(/-/g, '');
      return doc.articles.filter((art) => {
        if (appearance.compiledMode && art.isRevoked) return false;
        const artKey = normalizeArticleNumberKey(art.number);
        const cleanArtKey = artKey.replace(/-/g, '');
        return artKey === target || cleanArtKey === cleanTarget;
      });
    }

    const parsed = parseBooleanQuery(q, searchWithSynonyms);
    return doc.articles.filter((art) => {
      if (appearance.compiledMode && art.isRevoked) return false;
      const fullText = `${art.number} ${art.label} ${art.caputText} ${art.subClauses.map((sc) => sc.text).join(' ')} ${annotations[art.id]?.note || ''}`;
      return evaluateBooleanSearch(fullText, parsed, searchWithSynonyms);
    });
  }, [appliedFilterQuery, searchQuery, searchWithSynonyms, doc.articles, appearance.compiledMode, annotations]);

  // Stepper tracking for top search bar
  const currentTopMatchIndex = useMemo(() => {
    if (matchingArticles.length === 0 || !focusedArticleId) return 0;
    const idx = matchingArticles.findIndex((a) => a.id === focusedArticleId);
    return idx >= 0 ? idx : 0;
  }, [matchingArticles, focusedArticleId]);

  const handleJumpToNextMatch = () => {
    if (matchingArticles.length === 0) return;
    const nextIdx = currentTopMatchIndex < matchingArticles.length - 1 ? currentTopMatchIndex + 1 : 0;
    const target = matchingArticles[nextIdx];
    if (target) {
      setFocusedArticleId(target.id);
      scrollToElementId(target.id);
    }
  };

  const handleJumpToPrevMatch = () => {
    if (matchingArticles.length === 0) return;
    const prevIdx = currentTopMatchIndex > 0 ? currentTopMatchIndex - 1 : matchingArticles.length - 1;
    const target = matchingArticles[prevIdx];
    if (target) {
      setFocusedArticleId(target.id);
      scrollToElementId(target.id);
    }
  };

  // Top search bar matching articles (dropdown preview top 20)
  const topSearchResults = useMemo(() => {
    return matchingArticles.slice(0, 20);
  }, [matchingArticles]);

  // Load saved state on mount
  useEffect(() => {
    loadAppearanceSettings().then((loaded) => {
      setAppearance(loaded);
      syncVlibrasWidget(loaded.enableVlibras !== false, () => {
        const next = { ...loaded, enableVlibras: false };
        setAppearance(next);
        saveAppearanceSettings(next);
      });
      if (loaded.hideAITools) {
        setRightDrawerTab('notes');
      }
    });
    loadAIConfig().then(setAiConfig);
    loadHighlightTags().then(setHighlightTags);
    loadLawAnnotations(doc.lawId).then(async (localAnns) => {
      setAnnotations(localAnns);
      // Sincronização em nuvem Local-First (pull dos dados mais recentes se PRO)
      const cloudRes: any = await pullLawAnnotationsFromCloud(doc.lawId);
      const merged = cloudRes?.annotations || cloudRes;
      if (merged && typeof merged === 'object' && Object.keys(merged).length > 0) {
        setAnnotations(merged as Record<string, ArticleAnnotation>);
      }

      // Auto-highlight Multi-Legislações para Usuários PRO (se houver edital mapeado)
      const autoEdital = await getAutoHighlightsForCurrentLaw(doc);
      if (autoEdital && autoEdital.matches && autoEdital.matches.length > 0) {
        setEditalMatches(autoEdital.matches);
        setAnnotations((prev) => {
          const next = { ...prev };
          let changed = false;
          for (const m of autoEdital.matches) {
            if (!next[m.articleId]?.wholeHighlightColor) {
              changed = true;
              const existing = next[m.articleId] || {
                articleId: m.articleId,
                articleLabel: m.articleLabel,
                textHighlights: [],
                note: '',
                collapsed: false,
                updatedAt: new Date().toISOString(),
              };
              const editalNoteLine = `[Edital — ${m.editalTopic}]: ${m.reason}`;
              next[m.articleId] = {
                ...existing,
                wholeHighlightColor: autoEdital.targetTagId || 'orange',
                note:
                  autoEdital.addReasonToNotes &&
                  !existing.note.includes(editalNoteLine)
                    ? existing.note.trim()
                      ? `${existing.note.trim()}\n\n${editalNoteLine}`
                      : editalNoteLine
                    : existing.note,
                updatedAt: new Date().toISOString(),
              };
            }
          }
          if (changed) {
            saveLawAnnotations(doc.lawId, next);
          }
          return next;
        });
      }
    });

    refreshAuthAndPermissions();
    loadStudyTrailProgress(doc).then(setStudyProgress);
    getOabIncidenceForDocument(doc).then((res: any) => {
      setOabByArticleId((res?.byArticleId || {}) as Record<string, OabIncidenceItem>);
      setOabItems((res?.items || []) as OabIncidenceItem[]);
    });
  }, [doc.lawId]);

  // Assina estado do motor de áudio de artigos
  useEffect(() => {
    const unsub = subscribeAudioPlayer((state: any) => {
      setPlayingArticleId(state.isPlaying ? state.articleId : null);
    });
    return () => {
      unsub();
    };
  }, []);

  // IntersectionObserver para a Trilha do Edital (marca artigos lidos automaticamente ao avançar na leitura)
  useEffect(() => {
    if (!readerScrollRef.current) return;
    const detach = attachStudyTrailObserver({
      scrollRoot: readerScrollRef.current,
      onArticleRead: async (articleId: string) => {
        setStudyProgress((prev) => {
          if (prev?.readArticleIds?.includes(articleId)) return prev;
          markArticleAsRead(doc, prev, articleId).then(setStudyProgress);
          return prev;
        });
      },
      dwellTimeMs: 1800,
    });
    return () => detach();
  }, [doc, activeFilteredArticleIds, appearance.compiledMode]);

  // Close floating menus when clicking outside (Shadow DOM aware via composedPath)
  useEffect(() => {
    if (!showAppearancePopover && !showLawsMenu && !showTopSearchDropdown) {
      return;
    }

    const handlePointerDownOutside = (event: MouseEvent) => {
      const path = event.composedPath ? event.composedPath() : [];
      const isInside = (ref: React.RefObject<HTMLElement | null>) => {
        if (!ref.current) return false;
        return (
          path.includes(ref.current) ||
          ref.current.contains(event.target as Node)
        );
      };

      if (showLawsMenu && !isInside(lawsMenuRef)) {
        setShowLawsMenu(false);
      }
      if (showAppearancePopover && !isInside(appearanceMenuRef)) {
        setShowAppearancePopover(false);
      }
      if (showTopSearchDropdown && !isInside(topSearchRef)) {
        setShowTopSearchDropdown(false);
      }
    };

    window.addEventListener('mousedown', handlePointerDownOutside, true);
    return () => {
      window.removeEventListener('mousedown', handlePointerDownOutside, true);
    };
  }, [showAppearancePopover, showLawsMenu, showTopSearchDropdown]);

  const handleUpdateAppearance = (next: AppearanceSettings) => {
    syncVlibrasWidget(next.enableVlibras !== false, () => {
      const updated = { ...next, enableVlibras: false };
      setAppearance(updated);
      saveAppearanceSettings(updated);
    });
    if (next.isPcdAudioAccess !== appearance.isPcdAudioAccess) {
      const enabled = Boolean(next.isPcdAudioAccess);
      setPcdUserStatus(enabled);
      setIsPcd(enabled);
    }
    if (next.hideAITools !== appearance.hideAITools) {
      handleToggleHideAI(Boolean(next.hideAITools));
    } else {
      setAppearance(next);
      saveAppearanceSettings(next);
    }
  };

  const handlePlayArticleAudio = async (article: ArticleBlock) => {
    const res = await playArticleAudio(article, doc.lawId);
    if (!res.allowed) {
      handleOpenProDrawer('audio_article');
    }
  };

  const handleOpenLawPodcast = async () => {
    if (!isPro) {
      handleOpenProDrawer('podcast');
      return;
    }
    setPodcastOpen(true);
    if (podcastData) return;

    setPodcastLoading(true);
    try {
      const data = await loadOrGenerateLawPodcast(doc);
      setPodcastData(data);
    } finally {
      setPodcastLoading(false);
    }
  };

  const stopPodcastPlayback = () => {
    stopArticleAudio();
    if (podcastAudioRef.current) {
      podcastAudioRef.current.pause();
      podcastAudioRef.current = null;
    }
    if (podcastProgressTimerRef.current) {
      window.clearInterval(podcastProgressTimerRef.current);
      podcastProgressTimerRef.current = null;
    }
    setPodcastPlaying(false);
  };

  const handleTogglePodcastPlay = async () => {
    if (podcastPlaying) {
      stopPodcastPlayback();
      return;
    }
    if (!podcastData) return;

    setPodcastPlaying(true);

    if (podcastData.audioUrl) {
      try {
        const audio = new Audio(podcastData.audioUrl);
        audio.playbackRate = podcastSpeed;
        podcastAudioRef.current = audio;
        audio.ontimeupdate = () => {
          if (audio.duration) {
            setPodcastProgress(
              Math.min(100, Math.round((audio.currentTime / audio.duration) * 100))
            );
          }
        };
        audio.onended = () => {
          setPodcastPlaying(false);
          setPodcastProgress(100);
        };
        await audio.play();
        return;
      } catch {
        // Fallback para síntese local assistida do roteiro
      }
    }

    // Reprodução assistida do roteiro completo (dividido nas 3 seções)
    if (podcastProgressTimerRef.current) {
      window.clearInterval(podcastProgressTimerRef.current);
    }
    setPodcastProgress((p) => (p >= 100 ? 0 : p));
    podcastProgressTimerRef.current = window.setInterval(() => {
      setPodcastProgress((p) => (p < 96 ? p + 1 : p));
    }, 1500);

    const transcript =
      podcastData?.script?.fullTranscript ||
      `Panorama da norma ${doc.epigraph}.`;
    await speakWithNativeWebSpeech(
      transcript,
      `podcast-${doc.lawId}`,
      podcastSpeed
    );
    if (podcastProgressTimerRef.current) {
      window.clearInterval(podcastProgressTimerRef.current);
      podcastProgressTimerRef.current = null;
    }
    setPodcastPlaying(false);
    setPodcastProgress(100);
  };

  const handleChangePodcastSpeed = (speed: number) => {
    setPodcastSpeed(speed);
    if (podcastAudioRef.current) {
      podcastAudioRef.current.playbackRate = speed;
    }
  };

  const handleToggleHideAI = async (hide: boolean) => {
    const next = { ...appearance, hideAITools: hide };
    setAppearance(next);
    saveAppearanceSettings(next);

    if (hide) {
      // 1. Salvar dados ativos no armazenamento local em segundo plano
      if (chatMessages.length > 0 || quizQuestions.length > 0 || editalMatches.length > 0) {
        await saveAISessionBackup(doc.lawId, {
          chatMessages,
          quizQuestions,
          editalMatches,
          savedAt: new Date().toISOString(),
        });
      }
      // 2. PURGA ATIVA DA MEMÓRIA RAM: descarrega strings e componentes
      setChatMessages([]);
      setQuizQuestions([]);
      setEditalMatches([]);
      if (rightDrawerTab !== 'notes') {
        setRightDrawerTab('notes');
      }
    } else {
      // RESTAURAÇÃO: carrega do armazenamento local se houver sessão anterior
      try {
        const backup = await loadAISessionBackup(doc.lawId);
        if (backup) {
          if (backup.chatMessages && backup.chatMessages.length > 0) {
            setChatMessages(backup.chatMessages);
          }
          if (backup.quizQuestions && backup.quizQuestions.length > 0) {
            setQuizQuestions(backup.quizQuestions);
          }
          if (backup.editalMatches && backup.editalMatches.length > 0) {
            setEditalMatches(backup.editalMatches);
          }
        }
      } catch (err) {
        console.warn('Erro ao restaurar sessão de IA descarregada:', err);
      }
    }
  };

  const handleUpdateAIConfig = (next: AIConfig) => {
    setAiConfig(next);
    saveAIConfig(next);
    setAiError(null);
  };

  const handleUpdateHighlightTags = (next: HighlightTag[]) => {
    setHighlightTags(next);
    saveHighlightTags(next);
  };

  const handleUpdateAnnotation = (next: ArticleAnnotation) => {
    setAnnotations((prev) => {
      const updated = { ...prev, [next.articleId]: next };
      saveLawAnnotations(doc.lawId, updated);
      return updated;
    });
  };

  const handleImportAnnotations = (
    imported: Record<string, ArticleAnnotation>,
    importedTags?: HighlightTag[]
  ) => {
    setAnnotations(imported);
    saveLawAnnotations(doc.lawId, imported);
    if (importedTags && Array.isArray(importedTags) && importedTags.length > 0) {
      setHighlightTags(importedTags);
      saveHighlightTags(importedTags);
    }
  };

  const handleCopyAbntCitation = () => {
    navigator.clipboard?.writeText(abntCitation);
    setCopiedAbnt(true);
    setTimeout(() => setCopiedAbnt(false), 2200);
  };

  const focusedArticle: ArticleBlock | null =
    doc.articles.find((a) => a.id === focusedArticleId) ||
    doc.articles[0] ||
    null;

  const scrollToElementId = (elementId: string) => {
    const container = readerScrollRef.current;
    if (!container) return;
    const rootNode = container.getRootNode() as Document | ShadowRoot;
    const target = rootNode.getElementById(elementId);
    if (target) {
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  const handleSelectArticleFromToc = (articleId: string) => {
    setFocusedArticleId(articleId);
    scrollToElementId(articleId);
  };

  const handleSelectHeadingFromToc = (headingId: string) => {
    scrollToElementId(headingId);
  };

  // AI Actions (Integrated with zero-token IndexedDB local cache)
  const handleExplainArticle = async (article: ArticleBlock, forceRefresh = false) => {
    setFocusedArticleId(article.id);
    setRightDrawerOpen(true);
    setRightDrawerTab('chat');
    setAiError(null);

    // 1. Check zero-latency IndexedDB local cache first (0 tokens)
    if (!forceRefresh) {
      try {
        const cached = await getAICache(doc.lawId, article.id, 'explain');
        if (cached && cached.content) {
          const userMsg: ChatMessage = {
            id: `msg-${Date.now()}-u`,
            role: 'user',
            content: `Explique detalhadamente o ${article.label} com foco em doutrina e provas da OAB / Concursos.`,
            articleContext: article.label,
            timestamp: new Date().toISOString(),
          };
          const assistantMsg: ChatMessage = {
            id: `msg-${Date.now()}-a`,
            role: 'assistant',
            content: `${cached.content}\n\n> ⚡ *Resposta carregada instantaneamente do Cache Local IndexedDB (0 tokens gastos).*`,
            articleContext: article.label,
            timestamp: new Date().toISOString(),
          };
          setChatMessages((prev) => [...prev, userMsg, assistantMsg]);
          return;
        }
      } catch {
        // Fall through to AI execution
      }
    }

    const hasKey = Boolean(aiConfig.apiKeys[aiConfig.provider]?.trim());
    if (!hasKey) {
      setAiError(
        `Chave de API (${aiConfig.provider.toUpperCase()}) não configurada. Acesse o menu IA Chat > Chave API para inserir sua chave gratuita e utilizar a IA.`
      );
      return;
    }

    setIsLoadingAI(true);

    const userMsg: ChatMessage = {
      id: `msg-${Date.now()}-u`,
      role: 'user',
      content: `Explique detalhadamente o ${article.label} com foco em doutrina e provas da OAB / Concursos.`,
      articleContext: article.label,
      timestamp: new Date().toISOString(),
    };
    setChatMessages((prev) => [...prev, userMsg]);

    try {
      const reply = await explainArticleWithAI(
        aiConfig,
        doc.epigraph,
        article,
        { forceRefresh, lawId: doc.lawId }
      );
      const assistantMsg: ChatMessage = {
        id: `msg-${Date.now()}-a`,
        role: 'assistant',
        content: reply,
        articleContext: article.label,
        timestamp: new Date().toISOString(),
      };
      setChatMessages((prev) => [...prev, assistantMsg]);
    } catch (err) {
      setAiError(err instanceof Error ? err.message : String(err));
    } finally {
      setIsLoadingAI(false);
    }
  };

  const handleSummarizeJurisprudence = async (article: ArticleBlock, forceRefresh = false) => {
    setFocusedArticleId(article.id);
    setRightDrawerOpen(true);
    setRightDrawerTab('chat');
    setAiError(null);

    // 1. Check zero-latency IndexedDB local cache first (0 tokens)
    if (!forceRefresh) {
      try {
        const cached = await getAICache(doc.lawId, article.id, 'jurisprudence');
        if (cached && cached.content) {
          const userMsg: ChatMessage = {
            id: `msg-${Date.now()}-u`,
            role: 'user',
            content: `Sintetize as súmulas e a jurisprudência dominante do STF e STJ sobre o ${article.label}.`,
            articleContext: article.label,
            timestamp: new Date().toISOString(),
          };
          const assistantMsg: ChatMessage = {
            id: `msg-${Date.now()}-a`,
            role: 'assistant',
            content: `${cached.content}\n\n> ⚡ *Jurisprudência carregada instantaneamente do Cache Local IndexedDB (0 tokens gastos).*`,
            articleContext: article.label,
            timestamp: new Date().toISOString(),
          };
          setChatMessages((prev) => [...prev, userMsg, assistantMsg]);
          return;
        }
      } catch {
        // Fall through to AI execution
      }
    }

    const hasKey = Boolean(aiConfig.apiKeys[aiConfig.provider]?.trim());
    if (!hasKey) {
      setAiError(
        `Chave de API (${aiConfig.provider.toUpperCase()}) não configurada. Acesse o menu IA Chat > Chave API para inserir sua chave gratuita e utilizar a IA.`
      );
      return;
    }

    setIsLoadingAI(true);

    const userMsg: ChatMessage = {
      id: `msg-${Date.now()}-u`,
      role: 'user',
      content: `Sintetize as súmulas e a jurisprudência dominante do STF e STJ sobre o ${article.label}.`,
      articleContext: article.label,
      timestamp: new Date().toISOString(),
    };
    setChatMessages((prev) => [...prev, userMsg]);

    try {
      const reply = await summarizeArticleJurisprudenceWithAI(
        aiConfig,
        doc.epigraph,
        article,
        { forceRefresh, lawId: doc.lawId }
      );
      const assistantMsg: ChatMessage = {
        id: `msg-${Date.now()}-a`,
        role: 'assistant',
        content: reply,
        articleContext: article.label,
        timestamp: new Date().toISOString(),
      };
      setChatMessages((prev) => [...prev, assistantMsg]);
    } catch (err) {
      setAiError(err instanceof Error ? err.message : String(err));
    } finally {
      setIsLoadingAI(false);
    }
  };

  const handleGenerateQuiz = async (
    article: ArticleBlock | null,
    customTopic?: string,
    customParams?: QuizGenerationParams
  ) => {
    const activeParams = customParams || quizParams;
    if (article) setFocusedArticleId(article.id);
    setRightDrawerOpen(true);
    setRightDrawerTab('quiz');
    setAiError(null);

    const hasKey = Boolean(aiConfig.apiKeys[aiConfig.provider]?.trim());
    if (!hasKey) {
      setAiError(
        `Chave de API (${aiConfig.provider.toUpperCase()}) não configurada. Configure sua chave no menu IA Chat > Chave API para gerar questões personalizadas.`
      );
      return;
    }

    setIsLoadingAI(true);
    try {
      const questions = await generateArticleQuizWithAI(
        aiConfig,
        doc.epigraph,
        article,
        customTopic,
        previousQuizStatements,
        activeParams
      );
      setQuizQuestions(questions);
      if (questions.length > 0) {
        setPreviousQuizStatements((prev) => [
          ...prev,
          ...questions.map((q) => q.statement).filter(Boolean),
        ]);
      }
    } catch (err) {
      setAiError(err instanceof Error ? err.message : String(err));
    } finally {
      setIsLoadingAI(false);
    }
  };

  const handleGenerateFlashcards = async (
    customParams?: FlashcardGenerationParams
  ) => {
    const activeParams = customParams || flashcardParams;
    setRightDrawerOpen(true);
    setRightDrawerTab('quiz');
    setAiError(null);

    const highlightedArticleIds = new Set(
      Object.values(annotations)
        .filter(
          (a) => Boolean(a.wholeHighlightColor) || a.textHighlights.length > 0
        )
        .map((a) => a.articleId)
    );
    const highlightedArticles = doc.articles.filter((a) =>
      highlightedArticleIds.has(a.id)
    );

    const hasKey = Boolean(aiConfig.apiKeys[aiConfig.provider]?.trim());
    if (!hasKey) {
      setAiError(
        `Chave de API (${aiConfig.provider.toUpperCase()}) não configurada. Configure sua chave no menu IA Chat > Chave API para gerar flashcards.`
      );
      return;
    }

    setIsLoadingAI(true);
    try {
      const generated = await generateFlashcardsWithAI(
        aiConfig,
        doc,
        focusedArticle,
        highlightedArticles,
        activeParams
      );
      setFlashcards(generated);
    } catch (err) {
      setAiError(err instanceof Error ? err.message : String(err));
    } finally {
      setIsLoadingAI(false);
    }
  };

  const handleAnalyzeEdital = async (
    fileName: string,
    extractedText: string,
    pdfBase64: string | undefined,
    targetTagId: string,
    addReasonToNotes: boolean
  ) => {
    setAiError(null);
    setIsLoadingAI(true);

    try {
      const parsedRes = await parseEditalAndHighlight({
        aiConfig,
        doc,
        editalName: fileName,
        extractedText,
        pdfBase64,
        targetTagId,
        addReasonToNotes,
      });

      const matches = parsedRes.matches || [];
      setEditalMatches(matches);

      if (matches.length > 0) {
        const tagObj = resolveHighlightTag(targetTagId, highlightTags);
        const tagLabel = tagObj?.name || 'Edital';

        setAnnotations((prev) => {
          const next = { ...prev };
          for (const m of matches) {
            const existing = next[m.articleId] || {
              articleId: m.articleId,
              articleLabel: m.articleLabel,
              textHighlights: [],
              note: '',
              collapsed: false,
              updatedAt: new Date().toISOString(),
            };
            const editalNoteLine = `[Edital — ${m.editalTopic}]: ${m.reason}`;
            const updatedNote = addReasonToNotes
              ? existing.note.includes(editalNoteLine)
                ? existing.note
                : existing.note.trim()
                ? `${existing.note.trim()}\n\n${editalNoteLine}`
                : editalNoteLine
              : existing.note;

            next[m.articleId] = {
              ...existing,
              wholeHighlightColor: targetTagId,
              note: updatedNote,
              updatedAt: new Date().toISOString(),
            };
          }
          saveLawAnnotations(doc.lawId, next);
          return next;
        });

        handleSelectArticleFromToc(matches[0].articleId);
        void tagLabel;
      }
    } catch (err) {
      setAiError(err instanceof Error ? err.message : String(err));
    } finally {
      setIsLoadingAI(false);
    }
  };

  const handleSendChat = async (text: string) => {
    setAiError(null);

    const hasKey = Boolean(aiConfig.apiKeys[aiConfig.provider]?.trim());
    if (!hasKey && !isPro) {
      setAiError(
        `Chave de API (${aiConfig.provider.toUpperCase()}) não configurada. Insira sua chave gratuita na aba Chave API (BYOK) ou ative o Planalto Plus PRO para usar o "Pergunte à Lei" sem chaves.`
      );
      handleOpenProDrawer('ask_law');
      return;
    }

    const userMsg: ChatMessage = {
      id: `msg-${Date.now()}-u`,
      role: 'user',
      content: text,
      articleContext: focusedArticle?.label,
      timestamp: new Date().toISOString(),
    };
    const nextHistory = [...chatMessages, userMsg];
    setChatMessages(nextHistory);
    setIsLoadingAI(true);

    try {
      // Utiliza "Pergunte à Lei" ancorado na legislação aberta com extração de artigos citados
      const askRes = await askLawQuestion({
        question: text,
        doc,
        aiConfig,
      });

      let reply = askRes.answer || '';
      let citedArticles = askRes.citedArticles || [];

      if (!reply && hasKey) {
        reply = await sendLegalChatWithAI(
          aiConfig,
          doc.epigraph,
          focusedArticle,
          nextHistory,
          text
        );
        citedArticles = extractCitedArticlesFromAnswer(reply, doc);
      }

      const assistantMsg: ChatMessage = {
        id: `msg-${Date.now()}-a`,
        role: 'assistant',
        content: reply,
        articleContext: focusedArticle?.label,
        citedArticles,
        timestamp: new Date().toISOString(),
      };
      setChatMessages((prev) => [...prev, assistantMsg]);
    } catch (err) {
      setAiError(err instanceof Error ? err.message : String(err));
    } finally {
      setIsLoadingAI(false);
    }
  };

  const handleSelectQuizAnswer = (questionId: string, letter: string) => {
    setQuizQuestions((prev) =>
      prev.map((q) => (q.id === questionId ? { ...q, userAnswer: letter } : q))
    );
  };

  const themeColors = computeThemeColors(appearance);

  const rootThemeClass =
    appearance.theme === 'dark'
      ? 'dark text-zinc-100'
      : appearance.theme === 'sepia'
      ? 'text-[#2c2825]'
      : 'text-slate-900';

  const dropdownThemeClass =
    appearance.theme === 'dark'
      ? 'bg-zinc-950 border-zinc-800 text-zinc-100'
      : appearance.theme === 'sepia'
      ? 'bg-[#faf8f4] border-[#e2ddd3] text-[#2c2825]'
      : 'bg-white border-slate-200 text-slate-800';

  const annotationCount = Object.values(annotations).filter(
    (a) =>
      a.note.trim().length > 0 ||
      Boolean(a.wholeHighlightColor) ||
      a.textHighlights.length > 0
  ).length;

  const filteredLaws = RELEVANT_BRAZILIAN_LAWS.filter((law) => {
    const q = lawSearchQuery.trim().toLowerCase();
    if (!q) return true;
    return (
      law.shortName.toLowerCase().includes(q) ||
      law.fullName.toLowerCase().includes(q) ||
      law.category.toLowerCase().includes(q)
    );
  });

  const activeFontCss =
    FONT_FAMILY_CSS[appearance.fontFamily] || FONT_FAMILY_CSS.sans;
  const currentAccent = appearance.accentColor || '#6366f1';

  const isConstitution = useMemo(() => {
    return (
      doc.lawId.includes('constituicao') ||
      /constitui[çc][ãa]o/i.test(doc.epigraph) ||
      /constitui[çc][ãa]o/i.test(commonLawName)
    );
  }, [doc.lawId, doc.epigraph, commonLawName]);

  const openCadernoSubTab = (subTab: CadernoSubTab) => {
    setRightDrawerTab('notes');
    setCadernoSubTab(subTab);
    setRightDrawerOpen(true);
  };

  return (
    <div
      style={
        {
          fontFamily: activeFontCss,
          backgroundColor: themeColors.mainBg,
          '--app-font-family': activeFontCss,
          '--app-accent': currentAccent,
          '--app-accent-soft': hexToRgba(currentAccent, 0.14),
        } as React.CSSProperties
      }
      className={`planalto-app-root fixed inset-0 w-screen h-screen flex flex-col overflow-hidden transition-colors duration-150 ${rootThemeClass}`}
    >
      {/* Top Minimal Uncluttered Header Bar - Strictly Single-Row & Non-Wrapping */}
      <header
        style={{
          backgroundColor: themeColors.panelBg,
          borderColor: themeColors.borderColor,
        }}
        className="h-12 px-2.5 sm:px-4 border-b backdrop-blur-md flex items-center justify-between gap-1.5 sm:gap-2.5 shrink-0 z-30 select-none whitespace-nowrap overflow-x-clip"
      >
        {/* Left: Sumário Toggle, Common Law Title & Relevant Laws Switcher */}
        <div className="flex items-center gap-1.5 sm:gap-2 min-w-0 shrink-0">
          {!leftSidebarOpen && (
            <button
              type="button"
              onClick={() => setLeftSidebarOpen(true)}
              className="flex items-center gap-1.5 px-2 py-1.5 rounded-lg border border-current/15 hover:bg-black/5 dark:hover:bg-white/5 text-xs font-medium shrink-0 whitespace-nowrap"
              title="Abrir Sumário"
            >
              <PanelLeftOpen className="w-4 h-4 text-indigo-500" />
              <span className="hidden md:inline">Sumário</span>
            </button>
          )}

          {/* Common Law Title as Relevant Laws Dropdown Button */}
          <div ref={lawsMenuRef} className="relative min-w-0">
            <button
              type="button"
              onClick={() => {
                setShowLawsMenu((v) => !v);
                setShowAppearancePopover(false);
              }}
              className={`flex items-center gap-1.5 px-2 py-1 rounded-xl border transition-colors min-w-0 ${
                showLawsMenu
                  ? 'border-indigo-500 bg-indigo-500/10 text-indigo-600 dark:text-indigo-400'
                  : 'border-transparent hover:border-current/15 hover:bg-black/5 dark:hover:bg-white/5'
              }`}
              title={`${commonLawName} (${doc.epigraph}) — Clique para alternar para outras leis relevantes`}
            >
              <div className="w-6 h-6 rounded-lg bg-indigo-600 text-white flex items-center justify-center shrink-0 shadow-sm">
                <Scale className="w-3.5 h-3.5" />
              </div>
              <h1 className="font-bold text-xs sm:text-sm truncate max-w-[120px] sm:max-w-[200px] md:max-w-[260px] lg:max-w-[320px]">
                {commonLawName}
              </h1>
              <ChevronDown
                className={`w-3.5 h-3.5 opacity-75 shrink-0 transition-transform duration-150 ${
                  showLawsMenu ? 'rotate-180 text-indigo-500 opacity-100' : ''
                }`}
              />
            </button>

            {showLawsMenu && (
              <div
                style={{
                  backgroundColor: themeColors.cardBg,
                  borderColor: themeColors.borderColor,
                }}
                className={`absolute left-0 mt-2 w-80 sm:w-96 rounded-2xl border shadow-2xl p-3 space-y-2.5 z-50 ${dropdownThemeClass}`}
              >
                <div className="flex items-center justify-between border-b border-current/10 pb-2">
                  <span className="text-xs font-bold uppercase tracking-wider flex items-center gap-1.5">
                    <Library className="w-3.5 h-3.5 text-indigo-500" />
                    Legislações & Códigos Relevantes
                  </span>
                </div>

                <div className="relative">
                  <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 opacity-50" />
                  <input
                    type="text"
                    value={lawSearchQuery}
                    onChange={(e) => setLawSearchQuery(e.target.value)}
                    placeholder="Buscar lei (ex: CLT, Penal, Civil, OAB)..."
                    className="w-full pl-8 pr-3 py-1.5 rounded-xl border border-current/15 bg-transparent text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500/40"
                  />
                </div>

                <div className="max-h-72 overflow-y-auto space-y-1 pr-1">
                  {filteredLaws.map((law) => (
                    <a
                      key={law.id}
                      href={law.url}
                      onClick={() => setShowLawsMenu(false)}
                      className="flex items-center justify-between gap-2 p-2 rounded-xl hover:bg-indigo-500/10 transition-colors group"
                    >
                      <div className="min-w-0">
                        <div className="flex items-center gap-1.5">
                          <span className="font-bold text-xs group-hover:text-indigo-500">
                            {law.shortName}
                          </span>
                          <span className="text-[10px] px-1.5 py-0.2 rounded bg-black/5 dark:bg-white/10 opacity-70">
                            {law.category}
                          </span>
                        </div>
                        <p className="text-[11px] opacity-70 truncate">
                          {law.fullName}
                        </p>
                      </div>
                      <ExternalLink className="w-3.5 h-3.5 opacity-40 group-hover:opacity-100 group-hover:text-indigo-500 shrink-0" />
                    </a>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Center: Search Bar Centered in Top Header (With Integrated Match Counter & Stepper) */}
        <div
          ref={topSearchRef}
          className="relative flex-1 min-w-[170px] max-w-[240px] sm:max-w-[340px] md:max-w-[440px] lg:max-w-[540px] mx-1 sm:mx-2"
        >
          <button
            type="button"
            onClick={handleApplySearchFilter}
            className="w-4 h-4 absolute left-2 top-1/2 -translate-y-1/2 opacity-60 hover:opacity-100 cursor-pointer flex items-center justify-center text-current"
            title="Buscar artigos correspondentes (Enter)"
          >
            <Search className="w-3.5 h-3.5" />
          </button>
          <input
            type="text"
            value={searchQuery}
            onFocus={() => setShowTopSearchDropdown(true)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                e.preventDefault();
                if (!appliedFilterQuery && searchQuery.trim()) {
                  handleApplySearchFilter();
                } else if (e.shiftKey) {
                  handleJumpToPrevMatch();
                } else {
                  handleJumpToNextMatch();
                }
              }
            }}
            onChange={(e) => {
              const val = e.target.value;
              setSearchQuery(val);
              if (!val.trim()) {
                setAppliedFilterQuery(null);
                setShowTopSearchDropdown(false);
              } else {
                setShowTopSearchDropdown(true);
              }
            }}
            ref={topSearchInputRef}
            placeholder="Buscar ou nº do Art... (/)"
            className={`w-full pl-7 ${
              searchQuery.trim().length > 0
                ? 'pr-[155px] sm:pr-[170px]'
                : 'pr-20'
            } py-1.5 rounded-xl border border-current/15 bg-black/[0.03] dark:bg-white/[0.04] text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500/40 transition-all placeholder:truncate`}
          />
          <div className="absolute right-1.5 top-1/2 -translate-y-1/2 flex items-center gap-1">
            {/* Integrated Match Counter & Stepper Buttons */}
            {searchQuery.trim().length > 0 && (
              <div className="flex items-center gap-1 px-1.5 py-0.5 rounded-md bg-black/5 dark:bg-white/10 text-[10px] font-mono shrink-0 select-none">
                {matchingArticles.length > 0 ? (
                  <>
                    <span className="font-semibold text-indigo-600 dark:text-indigo-400 tabular-nums">
                      {currentTopMatchIndex + 1}/{matchingArticles.length}
                    </span>
                    <div className="flex items-center gap-0.5 border-l border-current/15 pl-1">
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleJumpToPrevMatch();
                        }}
                        className="p-0.5 rounded hover:bg-black/10 dark:hover:bg-white/15 opacity-70 hover:opacity-100 transition-colors"
                        title="Ocorrência anterior (Shift + Enter)"
                      >
                        <ChevronUp className="w-3 h-3" />
                      </button>
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleJumpToNextMatch();
                        }}
                        className="p-0.5 rounded hover:bg-black/10 dark:hover:bg-white/15 opacity-70 hover:opacity-100 transition-colors"
                        title="Próxima ocorrência (Enter)"
                      >
                        <ChevronDown className="w-3 h-3" />
                      </button>
                    </div>
                  </>
                ) : (
                  <span className="text-rose-500 font-semibold px-0.5">0/0</span>
                )}
              </div>
            )}

            <button
              type="button"
              onClick={() => setSearchWithSynonyms((v) => !v)}
              className={`px-1.5 py-0.5 rounded text-[10px] font-semibold transition-colors ${
                searchWithSynonyms
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'opacity-55 hover:opacity-100 border border-current/20'
              }`}
              title={
                searchWithSynonyms
                  ? 'Busca por sinônimos ativada (Clique para desativar)'
                  : 'Ativar busca por sinônimos e termos jurídicos correlatos'
              }
            >
              Sinônimos
            </button>
            {searchQuery && (
              <button
                type="button"
                onClick={() => {
                  setSearchQuery('');
                  setAppliedFilterQuery(null);
                  setShowTopSearchDropdown(false);
                }}
                className="p-0.5 rounded hover:bg-black/10 dark:hover:bg-white/10 opacity-60 hover:opacity-100"
                title="Limpar busca"
              >
                <X className="w-3 h-3" />
              </button>
            )}
          </div>

          {/* Live Search Results Dropdown for Centered Top Search Bar */}
          {showTopSearchDropdown && searchQuery.trim().length > 0 && (
            <div
              style={{
                backgroundColor: themeColors.cardBg,
                borderColor: themeColors.borderColor,
              }}
              className={`absolute left-0 right-0 mt-2 rounded-2xl border shadow-2xl p-2 max-h-80 overflow-y-auto z-50 ${dropdownThemeClass}`}
            >
              <div className="px-2 py-1 text-[10px] font-semibold uppercase tracking-wider opacity-60 flex items-center justify-between">
                <span>Resultados na Lei</span>
                <span>{topSearchResults.length} encontrados</span>
              </div>
              {topSearchResults.length === 0 ? (
                <div className="p-4 text-center text-xs opacity-60">
                  Nenhum artigo encontrado para "{searchQuery}".
                </div>
              ) : (
                <div className="space-y-1 mt-1">
                  {topSearchResults.map((art) => (
                    <button
                      key={art.id}
                      type="button"
                      onClick={() => {
                        handleSelectArticleFromToc(art.id);
                        setShowTopSearchDropdown(false);
                      }}
                      className="w-full text-left p-2 rounded-xl hover:bg-indigo-500/10 transition-colors flex flex-col gap-0.5"
                    >
                      <span className="font-bold text-xs text-indigo-600 dark:text-indigo-400">
                        {art.label}
                      </span>
                      <p className="text-[11px] opacity-80 line-clamp-2 leading-snug">
                        {art.caputText}
                      </p>
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Right: Quick Controls (Texto Compilado, Appearance, Caderno, IA Chat, Original View) */}
        <div className="flex items-center gap-1 sm:gap-1.5 shrink-0 relative justify-end whitespace-nowrap">
          {/* Texto Compilado Toggle with Rich Custom Tooltip */}
          <div className="relative group/compilado shrink-0">
            <button
              type="button"
              onClick={() =>
                handleUpdateAppearance({
                  ...appearance,
                  compiledMode: !appearance.compiledMode,
                })
              }
              className={`flex items-center gap-1 sm:gap-1.5 px-2 sm:px-2.5 py-1.5 rounded-lg text-xs font-medium border transition-colors shrink-0 whitespace-nowrap ${
                appearance.compiledMode
                  ? appearance.theme === 'dark'
                    ? 'border-emerald-400/50 bg-emerald-400/15 text-emerald-300 shadow-sm font-semibold'
                    : appearance.theme === 'sepia'
                    ? 'border-emerald-800/40 bg-emerald-800/15 text-emerald-950 shadow-sm font-semibold'
                    : 'border-emerald-700/50 bg-emerald-700/15 text-emerald-800 shadow-sm font-semibold'
                  : 'border-current/15 opacity-75 hover:opacity-100'
              }`}
            >
              <CheckCheck className="w-3.5 h-3.5" />
              <span className="hidden xl:inline">Texto Compilado</span>
              <HelpCircle className="w-3 h-3 opacity-60" />
            </button>

            {/* Explanatory Tooltip on Hover */}
            <div
              style={{
                backgroundColor: themeColors.cardBg,
                borderColor: themeColors.borderColor,
              }}
              className={`pointer-events-none opacity-0 group-hover/compilado:opacity-100 transition-opacity duration-150 absolute right-0 sm:right-auto sm:left-0 top-full mt-2 w-72 sm:w-80 p-3 rounded-xl border shadow-xl text-[11px] leading-relaxed whitespace-normal break-words z-[60] ${dropdownThemeClass}`}
            >
              <div
                className={`font-bold mb-1 flex items-center gap-1 ${
                  appearance.theme === 'dark'
                    ? 'text-emerald-400'
                    : appearance.theme === 'sepia'
                    ? 'text-emerald-900'
                    : 'text-emerald-700'
                }`}
              >
                <CheckCheck className="w-3.5 h-3.5" />
                <span>O que é o Texto Compilado?</span>
              </div>
              <p className="opacity-85 whitespace-normal break-words">
                Quando ativado, oculta automaticamente os dispositivos revogados
                (textos riscados) e minimiza anotações legislativas como{' '}
                <em>"(Redação dada / Incluído pela Lei nº X)"</em> em pequenos
                ícones com tooltip para uma leitura limpa.
              </p>
            </div>
          </div>

          {/* Appearance Popover Button */}
          <div ref={appearanceMenuRef} className="relative shrink-0">
            <button
              type="button"
              onClick={() => {
                setShowAppearancePopover((v) => !v);
                setShowLawsMenu(false);
              }}
              className={`flex items-center gap-1.5 px-2 sm:px-2.5 py-1.5 rounded-lg text-xs font-medium border transition-colors shrink-0 whitespace-nowrap ${
                showAppearancePopover
                  ? 'border-indigo-500 bg-indigo-500/10 text-indigo-600 dark:text-indigo-400'
                  : 'border-current/15 hover:bg-black/5 dark:hover:bg-white/5'
              }`}
              title="Tema (Claro/Sépia/Escuro), Cor de Destaque, Fonte e Espaçamento"
            >
              <Type className="w-3.5 h-3.5" />
              <span className="hidden lg:inline">Aparência</span>
            </button>

            {showAppearancePopover && (
              <div className="absolute right-0 mt-2 z-[70]">
                <AppearancePopover
                  settings={appearance}
                  onChange={handleUpdateAppearance}
                  onClose={() => setShowAppearancePopover(false)}
                />
              </div>
            )}
          </div>

          {/* Caderno Button (Contains Grifos & Tags and Anotações sub-tabs) */}
          <button
            type="button"
            onClick={() => {
              setRightDrawerTab('notes');
              setRightDrawerOpen((open) =>
                rightDrawerTab === 'notes' ? !open : true
              );
            }}
            className={`flex items-center gap-1.5 px-2 sm:px-2.5 py-1.5 rounded-lg text-xs font-medium border transition-colors shrink-0 whitespace-nowrap ${
              rightDrawerOpen && rightDrawerTab === 'notes'
                ? 'border-amber-500 bg-amber-500/15 text-amber-700 dark:text-amber-300 font-semibold'
                : 'border-current/15 hover:bg-black/5 dark:hover:bg-white/5 opacity-85 hover:opacity-100'
            }`}
            title="Caderno (Grifos & Tags e Anotações)"
          >
            <BookMarked className="w-3.5 h-3.5 text-amber-500" />
            <span className="hidden lg:inline">Caderno</span>
            {annotationCount > 0 && (
              <span className="px-1.5 py-0.2 rounded-full bg-amber-500/20 text-amber-600 dark:text-amber-400 text-[10px] font-bold">
                {annotationCount}
              </span>
            )}
          </button>

          {/* IA Chat Button (contains Chat, Importar Edital, and Chave API) */}
          {!appearance.hideAITools && (
            <button
              type="button"
              onClick={() => {
                setRightDrawerTab('chat');
                setRightDrawerOpen((open) =>
                  rightDrawerTab === 'chat' ? !open : true
                );
              }}
              className={`flex items-center gap-1.5 px-2 sm:px-2.5 py-1.5 rounded-lg text-xs font-medium border transition-colors shrink-0 whitespace-nowrap ${
                rightDrawerOpen && rightDrawerTab === 'chat'
                  ? 'border-indigo-500 bg-indigo-500/15 text-indigo-600 dark:text-indigo-400 font-semibold'
                  : 'border-current/15 hover:bg-black/5 dark:hover:bg-white/5 opacity-85 hover:opacity-100'
              }`}
              title="Abrir IA Chat (Conversa, Importar Edital e Chave API)"
            >
              <MessageSquare className="w-3.5 h-3.5 text-indigo-500" />
              <span className="hidden lg:inline">IA Chat</span>
            </button>
          )}

          {/* Switch back to Original Planalto View */}
          <button
            type="button"
            onClick={onToggleOriginalView}
            className="flex items-center gap-1 px-2 py-1.5 rounded-lg border border-current/15 hover:bg-black/5 dark:hover:bg-white/5 text-xs opacity-75 hover:opacity-100 shrink-0 whitespace-nowrap"
            title="Alternar para o layout original do Planalto"
          >
            <Eye className="w-3.5 h-3.5" />
            <span className="hidden 2xl:inline">Original</span>
          </button>

          {/* Subtle PRO / Account Button (Zero Visual Pollution) */}
          <button
            type="button"
            onClick={() => handleOpenProDrawer('default')}
            className={`flex items-center gap-1 px-2 py-1.5 rounded-lg text-xs font-medium border transition-colors shrink-0 whitespace-nowrap ${
              isPro
                ? 'border-emerald-500/40 bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 font-semibold'
                : 'border-current/15 opacity-75 hover:opacity-100 hover:bg-black/5 dark:hover:bg-white/5'
            }`}
            title="Conta, Sincronização em Nuvem, Acessibilidade PcD e Recursos PRO"
          >
            <Sparkles className="w-3.5 h-3.5 text-indigo-500" />
            <span>{isPro ? 'PRO Ativo' : 'PRO'}</span>
          </button>

          {!rightDrawerOpen && (
            <button
              type="button"
              onClick={() => setRightDrawerOpen(true)}
              className="p-1.5 rounded-lg border border-current/15 hover:bg-black/5 dark:hover:bg-white/5 shrink-0"
              title="Expandir painel lateral direito"
            >
              <PanelRightOpen className="w-4 h-4" />
            </button>
          )}
        </div>
      </header>

      {/* Main 3-Zone Workspace */}
      <div className="flex-1 flex min-h-0 overflow-hidden">
        {/* Zone 1: Left Collapsible Hierarchical Sumário Sidebar */}
        {leftSidebarOpen && (
          <TocSidebar
            toc={doc.toc}
            articles={doc.articles}
            annotations={annotations}
            activeArticleId={focusedArticleId}
            compiledMode={appearance.compiledMode}
            appearance={appearance}
            searchQuery={searchQuery}
            searchWithSynonyms={searchWithSynonyms}
            onSearchQueryChange={(val) => {
              setSearchQuery(val);
              if (!val.trim()) {
                setAppliedFilterQuery(null);
              }
            }}
            onSelectHeading={handleSelectHeadingFromToc}
            onSelectArticle={handleSelectArticleFromToc}
            onCollapse={() => setLeftSidebarOpen(false)}
            onOpenShortcuts={() => setShowShortcutsModal(true)}
          />
        )}

        {/* Zone 2: Center Legislation Reader */}
        <main
          ref={readerScrollRef}
          style={{ fontFamily: activeFontCss }}
          className="flex-1 overflow-y-auto px-4 sm:px-8 py-8 scroll-smooth"
        >
          <div
            style={{
              maxWidth: `${appearance.maxWidth}px`,
              fontSize: `${appearance.fontSize}px`,
              lineHeight: appearance.lineHeight,
              fontFamily: activeFontCss,
            }}
            className="mx-auto pb-28"
          >
            {/* Law Epigraph, Article Count Above Ementa & Serif Quote Boxes (Ementa + Preâmbulo) */}
            <div
              style={{
                backgroundColor: themeColors.panelBg,
                borderColor: themeColors.borderColor,
              }}
              className="mb-8 p-6 rounded-2xl border transition-colors"
            >
              <div className="flex flex-wrap items-center justify-between gap-2 mb-1.5">
                <div className="text-xs font-bold uppercase tracking-widest text-indigo-600 dark:text-indigo-400">
                  Presidência da República • Legislação Federal
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  {/* Discrete Button: [🎧 Ouvir Panorama da Lei (15 min)] (Recurso PRO Exclusivo) */}
                  <button
                    type="button"
                    onClick={handleOpenLawPodcast}
                    className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold border border-current/15 hover:border-indigo-500/50 hover:bg-indigo-500/10 transition-colors"
                    title="Ouvir episódio de podcast panorâmico de 15 minutos sobre esta lei (Gemini Flash 1M + Google Cloud TTS WaveNet)"
                  >
                    <Headphones className="w-3.5 h-3.5 text-indigo-500" />
                    <span>🎧 Ouvir Panorama da Lei (15 min)</span>
                    <span className="px-1.5 py-0.2 rounded text-[9px] font-bold uppercase tracking-wider bg-black/5 dark:bg-white/10 opacity-75">
                      PRO
                    </span>
                  </button>

                  {/* Article Count Badge Moved Above Ementa */}
                  <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 border border-indigo-500/20">
                    <FileText className="w-3.5 h-3.5" />
                    {doc.articles.length} artigos nesta norma
                  </span>
                </div>
              </div>

              {/* Dedicated Law Podcast Player (Progress Bar + Speed Selector 0.75x to 2x) */}
              {podcastOpen && isPro && (
                <div
                  style={{
                    backgroundColor: themeColors.cardBg,
                    borderColor: themeColors.borderColor,
                  }}
                  className="my-3 p-4 rounded-2xl border shadow-sm space-y-3 text-xs"
                >
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-xl bg-indigo-600 text-white flex items-center justify-center shrink-0">
                        <Headphones className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="font-bold text-xs sm:text-sm flex items-center gap-1.5">
                          <span>
                            {podcastData?.script?.title ||
                              `Panorama da Lei — ${doc.epigraph}`}
                          </span>
                          <span className="px-1.5 py-0.2 rounded text-[9px] font-bold uppercase bg-emerald-500/15 text-emerald-600 dark:text-emerald-400">
                            {podcastData?.cached
                              ? 'Cache Global (0ms)'
                              : 'WaveNet pt-BR'}
                          </span>
                        </div>
                        <p className="text-[11px] opacity-70">
                          1. Objetivo e Contexto • 2. Conceitos Extensivos • 3.
                          Top 7 Artigos Mais Cobrados
                        </p>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => {
                        stopPodcastPlayback();
                        setPodcastOpen(false);
                      }}
                      className="p-1 rounded-lg hover:bg-black/10 dark:hover:bg-white/10 opacity-70 hover:opacity-100"
                      title="Fechar Player do Podcast"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>

                  {podcastLoading ? (
                    <div className="py-3 text-center text-xs opacity-75">
                      Verificando Cache Global no Supabase Storage (`
                      {podcastData?.storagePath || 'podcasts/lei.mp3'}`)...
                    </div>
                  ) : (
                    <>
                      <div className="flex flex-wrap items-center gap-3">
                        <button
                          type="button"
                          onClick={handleTogglePodcastPlay}
                          className="px-3.5 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs flex items-center gap-1.5 shadow-sm transition-colors shrink-0"
                        >
                          {podcastPlaying ? (
                            <>
                              <Pause className="w-3.5 h-3.5" />
                              <span>Pausar</span>
                            </>
                          ) : (
                            <>
                              <Play className="w-3.5 h-3.5" />
                              <span>Reproduzir Episódio</span>
                            </>
                          )}
                        </button>

                        {/* Barra de Progresso Dedicada */}
                        <div className="flex-1 min-w-[140px] space-y-1">
                          <div className="w-full h-2 rounded-full bg-black/10 dark:bg-white/10 overflow-hidden">
                            <div
                              className="h-full bg-indigo-600 transition-all duration-300"
                              style={{ width: `${podcastProgress}%` }}
                            />
                          </div>
                          <div className="flex items-center justify-between text-[10px] opacity-65">
                            <span>Progresso: {podcastProgress}%</span>
                            <span>Duração estimada: ~15 min</span>
                          </div>
                        </div>

                        {/* Seletor de Velocidade (0.75x a 2x) */}
                        <div className="flex items-center gap-1 shrink-0">
                          <span className="text-[10px] opacity-70 mr-0.5">
                            Velocidade:
                          </span>
                          {PODCAST_SPEED_OPTIONS.map((spd: number) => (
                            <button
                              key={spd}
                              type="button"
                              onClick={() => handleChangePodcastSpeed(spd)}
                              className={`px-1.5 py-0.5 rounded text-[10px] font-bold transition-colors ${
                                podcastSpeed === spd
                                  ? 'bg-indigo-600 text-white'
                                  : 'border border-current/15 opacity-75 hover:opacity-100'
                              }`}
                            >
                              {spd}x
                            </button>
                          ))}
                        </div>
                      </div>

                      <div className="pt-1 border-t border-current/10 flex items-center justify-between">
                        <span className="text-[10px] opacity-65">
                          Arquivo: `{podcastData?.storagePath}`
                        </span>
                        <button
                          type="button"
                          onClick={() => setShowPodcastTranscript((v) => !v)}
                          className="text-[11px] font-semibold text-indigo-600 dark:text-indigo-400 hover:underline"
                        >
                          {showPodcastTranscript
                            ? 'Ocultar roteiro estruturado'
                            : 'Ver roteiro estruturado (3 partes)'}
                        </button>
                      </div>

                      {showPodcastTranscript &&
                        podcastData?.script?.sections && (
                          <div className="space-y-2 pt-2 border-t border-current/10 max-h-56 overflow-y-auto pr-1">
                            {podcastData.script.sections.map((sec: any) => (
                              <div
                                key={sec.id}
                                className="p-2.5 rounded-xl bg-black/[0.03] dark:bg-white/[0.03] space-y-1"
                              >
                                <div className="font-bold text-[11px] text-indigo-600 dark:text-indigo-400">
                                  {sec.title}
                                </div>
                                <p className="text-[11px] opacity-85 leading-relaxed">
                                  {sec.content}
                                </p>
                              </div>
                            ))}
                          </div>
                        )}
                    </>
                  )}
                </div>
              )}

              {/* Official Epigraph Title Preserved in the Body of the Law */}
              <h2 className="text-xl sm:text-2xl font-extrabold tracking-tight mb-4">
                {doc.epigraph}
              </h2>

              {/* Top cross-reference hyperlinks / remissões at the beginning of the law */}
              {doc.headerLinks && doc.headerLinks.length > 0 && (
                <div
                  style={{
                    backgroundColor: themeColors.cardBg,
                    borderColor: themeColors.borderColor,
                  }}
                  className="my-3 p-3 rounded-xl border shadow-sm space-y-2 text-xs"
                >
                  <div className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
                    <ExternalLink className="w-3 h-3" />
                    <span>Atos Vinculados & Remissões</span>
                  </div>
                  <div className="flex flex-wrap items-center gap-1.5">
                    {doc.headerLinks.map((link) => (
                      <a
                        key={link.id}
                        href={link.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-medium border border-current/15 hover:border-indigo-500/50 hover:bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 transition-colors"
                        title={link.text}
                      >
                        <span>{link.text}</span>
                        <ExternalLink className="w-2.5 h-2.5 opacity-60 shrink-0" />
                      </a>
                    ))}
                  </div>
                </div>
              )}

              {/* Ementa in a dedicated Quote Box with Explicit Serif font + ABNT Citation Copy Icon at the bottom (Leis comuns) */}
              {!isConstitution && doc.ementa && (
                <blockquote
                  style={{
                    fontFamily: FONT_FAMILY_CSS.serif,
                    backgroundColor: themeColors.cardBg,
                    borderColor: themeColors.borderColor,
                  }}
                  className="font-serif relative p-4 sm:p-5 rounded-xl border border-l-4 border-l-indigo-500 shadow-sm my-3"
                >
                  <div className="flex items-start gap-3">
                    <Quote className="w-5 h-5 text-indigo-500/70 shrink-0 mt-0.5" />
                    <div className="space-y-1 flex-1 min-w-0">
                      <span
                        style={{ fontFamily: FONT_FAMILY_CSS.sans }}
                        className="block text-[10px] font-bold uppercase tracking-widest text-indigo-600 dark:text-indigo-400"
                      >
                        Ementa Oficial
                      </span>
                      <p className="text-sm sm:text-base italic leading-relaxed">
                        “{doc.ementa}”
                      </p>
                    </div>
                  </div>

                  {/* Bottom of Ementa: Copy Law as ABNT Citation */}
                  <div
                    style={{ fontFamily: FONT_FAMILY_CSS.sans }}
                    className="mt-3 pt-2.5 border-t border-current/10 flex items-center justify-end"
                  >
                    <button
                      type="button"
                      onClick={handleCopyAbntCitation}
                      className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[11px] font-medium border border-current/15 hover:border-indigo-500/40 hover:bg-indigo-500/10 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors"
                      title={`Copiar citação ABNT: ${abntCitation}`}
                    >
                      {copiedAbnt ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-500" />
                          <span className="text-emerald-600 dark:text-emerald-400 font-semibold">
                            Citação ABNT copiada!
                          </span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5 opacity-75" />
                          <span>Copiar citação ABNT</span>
                        </>
                      )}
                    </button>
                  </div>
                </blockquote>
              )}

              {/* Preâmbulo destacado como se ementa fosse (Apenas na Constituição Federal) */}
              {isConstitution && doc.preambulo.length > 0 && (
                <blockquote
                  style={{
                    fontFamily: FONT_FAMILY_CSS.serif,
                    backgroundColor: themeColors.cardBg,
                    borderColor: themeColors.borderColor,
                  }}
                  className="font-serif relative p-4 sm:p-5 rounded-xl border border-l-4 border-l-indigo-500 shadow-sm my-3"
                >
                  <div className="flex items-start gap-3">
                    <Quote className="w-5 h-5 text-indigo-500/70 shrink-0 mt-0.5" />
                    <div className="space-y-1.5 flex-1 min-w-0">
                      <span
                        style={{ fontFamily: FONT_FAMILY_CSS.sans }}
                        className="block text-[10px] font-bold uppercase tracking-widest text-indigo-600 dark:text-indigo-400"
                      >
                        Preâmbulo
                      </span>
                      {doc.preambulo
                        .filter((p) => !/^PRE[ÂA]MBULO$/i.test(p.trim()))
                        .map((p, idx) => (
                          <p
                            key={idx}
                            className="text-sm sm:text-base italic leading-relaxed"
                          >
                            “{p}”
                          </p>
                        ))}
                    </div>
                  </div>

                  {/* Bottom of Preâmbulo: Copy Law as ABNT Citation */}
                  <div
                    style={{ fontFamily: FONT_FAMILY_CSS.sans }}
                    className="mt-3 pt-2.5 border-t border-current/10 flex items-center justify-end"
                  >
                    <button
                      type="button"
                      onClick={handleCopyAbntCitation}
                      className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[11px] font-medium border border-current/15 hover:border-indigo-500/40 hover:bg-indigo-500/10 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors"
                      title={`Copiar citação ABNT: ${abntCitation}`}
                    >
                      {copiedAbnt ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-500" />
                          <span className="text-emerald-600 dark:text-emerald-400 font-semibold">
                            Citação ABNT copiada!
                          </span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5 opacity-75" />
                          <span>Copiar citação ABNT</span>
                        </>
                      )}
                    </button>
                  </div>
                </blockquote>
              )}

              {/* Preâmbulo em leis ordinárias / códigos (Texto introdutório não destacado como ementa) */}
              {!isConstitution && doc.preambulo.length > 0 && (
                <div className="text-xs sm:text-sm opacity-80 font-sans my-3 px-1 leading-relaxed italic">
                  {doc.preambulo
                    .filter((p) => !/^PRE[ÂA]MBULO$/i.test(p.trim()))
                    .map((p, idx) => (
                      <p key={idx}>{p}</p>
                    ))}
                </div>
              )}
            </div>

            {/* Filter Banner when Search is active */}
            {activeFilteredArticleIds && (
              <div
                style={{
                  backgroundColor: themeColors.cardBg,
                  borderColor: themeColors.borderColor,
                }}
                className="mb-6 p-4 rounded-2xl border shadow-sm flex flex-wrap items-center justify-between gap-3 text-xs"
              >
                <div className="flex items-center gap-2">
                  <div className="p-1.5 rounded-lg bg-indigo-500/15 text-indigo-600 dark:text-indigo-400">
                    <Search className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="font-semibold">
                      Exibindo {activeFilteredArticleIds.size} artigo(s) para "
                      <span className="text-indigo-600 dark:text-indigo-400">
                        {appliedFilterQuery}
                      </span>
                      "
                    </span>
                    {searchWithSynonyms && (
                      <span className="ml-2 px-1.5 py-0.5 rounded-full text-[10px] bg-indigo-600 text-white font-semibold">
                        Sinônimos ativos
                      </span>
                    )}
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setAppliedFilterQuery(null);
                    setSearchQuery('');
                  }}
                  className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-medium text-xs transition-colors shrink-0 flex items-center gap-1"
                >
                  <X className="w-3.5 h-3.5" />
                  <span>Limpar filtro e ver todos</span>
                </button>
              </div>
            )}

            {activeFilteredArticleIds && activeFilteredArticleIds.size === 0 && (
              <div
                style={{
                  backgroundColor: themeColors.cardBg,
                  borderColor: themeColors.borderColor,
                }}
                className="my-8 p-8 rounded-2xl border text-center space-y-3"
              >
                <p className="text-sm opacity-70">
                  Nenhum artigo correspondente encontrado para "{appliedFilterQuery}".
                </p>
                <button
                  type="button"
                  onClick={() => {
                    setAppliedFilterQuery(null);
                    setSearchQuery('');
                  }}
                  className="px-4 py-2 rounded-xl bg-indigo-600 text-white text-xs font-semibold hover:bg-indigo-500"
                >
                  Ver lei completa
                </button>
              </div>
            )}

            {/* Structured Blocks (Headings + Articles + Text) */}
            {doc.blocks.map((block) => {
              if (activeFilteredArticleIds) {
                if (block.kind === 'article') {
                  if (!activeFilteredArticleIds.has(block.article.id)) return null;
                } else if (block.kind === 'heading') {
                  const hasMatching = block.node.articles.some((a) =>
                    activeFilteredArticleIds.has(a.id)
                  );
                  if (!hasMatching) return null;
                } else {
                  return null;
                }
              }
              if (block.kind === 'heading') {
                const { node } = block;
                const isMajor =
                  node.level === 'parte' ||
                  node.level === 'livro' ||
                  node.level === 'titulo';
                const isAdctRoot =
                  node.isAdct &&
                  /^ATO\s+DAS\s+DISPOSI[ÇC][ÕO]ES/i.test(node.title);

                return (
                  <React.Fragment key={node.id}>
                    {isAdctRoot && (
                      <div
                        id={node.id}
                        className="my-12 p-6 rounded-2xl border-2 border-amber-500/40 bg-amber-500/5 text-center space-y-2"
                      >
                        <span className="inline-block px-3 py-0.5 rounded-full bg-amber-500/20 text-amber-600 dark:text-amber-400 text-xs font-bold uppercase tracking-widest">
                          Transição Constitucional • ADCT
                        </span>
                        <h3 className="text-xl sm:text-2xl font-extrabold tracking-tight">
                          {node.title}
                        </h3>
                        <p className="text-xs sm:text-sm opacity-75">
                          Início do Ato das Disposições Constitucionais
                          Transitórias.
                        </p>
                      </div>
                    )}

                    {!isAdctRoot && (
                      <div
                        id={node.id}
                        className={`my-8 pt-4 text-center ${
                          isMajor ? 'border-t border-current/10 pt-8' : ''
                        }`}
                      >
                        <div
                          className={`font-bold tracking-wide uppercase ${
                            isMajor
                              ? 'text-lg sm:text-xl text-indigo-600 dark:text-indigo-400'
                              : 'text-base sm:text-lg opacity-90'
                          }`}
                        >
                          {node.title}
                        </div>
                        {node.subtitle && node.level !== 'parte' && (
                          <div className="text-sm sm:text-base font-medium opacity-75 mt-1">
                            {node.subtitle}
                          </div>
                        )}
                      </div>
                    )}
                  </React.Fragment>
                );
              }

              if (block.kind === 'article') {
                const { article } = block;
                return (
                  <ArticleItem
                    key={article.id}
                    article={article}
                    previousArticle={previousArticleById[article.id]}
                    lawEpigraph={doc.epigraph}
                    annotation={annotations[article.id]}
                    highlightTags={highlightTags}
                    appearance={appearance}
                    searchHighlightWords={searchHighlightWords}
                    crossRefGraph={crossRefGraph}
                    isFocused={focusedArticleId === article.id}
                    onFocus={() => setFocusedArticleId(article.id)}
                    onJumpToArticle={handleSelectArticleFromToc}
                    onOpenCrossRefGraphForArticle={(targetArt) => {
                      setCrossRefModalArticle(targetArt);
                      setShowCrossRefModal(true);
                    }}
                    onUpdateAnnotation={handleUpdateAnnotation}
                    onOpenCustomizeTags={() => openCadernoSubTab('grifos')}
                    onExplainWithAI={handleExplainArticle}
                    onSummarizeJurisprudenceWithAI={
                      handleSummarizeJurisprudence
                    }
                    onQuizWithAI={(art) => {
                      setFocusedArticleId(art.id);
                      setRightDrawerOpen(true);
                      setRightDrawerTab('quiz');
                    }}
                    onPlayAudio={handlePlayArticleAudio}
                    isPlayingAudio={playingArticleId === article.id}
                    isPro={isPro}
                    isPcd={isPcd}
                    oabIncidence={oabByArticleId[article.id]}
                    isReadInTrail={Boolean(
                      studyProgress?.readArticleIds?.includes(article.id)
                    )}
                  />
                );
              }

              if (appearance.compiledMode && block.isRevoked) {
                return null;
              }

              return (
                <div
                  key={block.id}
                  style={{ marginBottom: `${appearance.paragraphSpacing}px` }}
                  className={`px-4 opacity-85 font-medium ${
                    block.isRevoked ? 'line-through opacity-45' : ''
                  }`}
                >
                  <span>{block.text}</span>
                  <ModificationNoteBadge
                    note={block.modificationNote}
                    url={block.modificationUrl}
                    compiledMode={appearance.compiledMode}
                    theme={appearance.theme}
                  />
                </div>
              );
            })}
          </div>
        </main>

        {/* Zone 3: Right Collapsible Drawer */}
        {rightDrawerOpen && (
          <RightDrawer
            activeTab={rightDrawerTab}
            onTabChange={setRightDrawerTab}
            cadernoSubTab={cadernoSubTab}
            onCadernoSubTabChange={setCadernoSubTab}
            hideAITools={Boolean(appearance.hideAITools)}
            onToggleHideAI={handleToggleHideAI}
            onClose={() => setRightDrawerOpen(false)}
            appearance={appearance}
            doc={doc}
            focusedArticle={focusedArticle}
            annotations={annotations}
            highlightTags={highlightTags}
            onChangeHighlightTags={handleUpdateHighlightTags}
            onImportAnnotations={handleImportAnnotations}
            onJumpToArticle={handleSelectArticleFromToc}
            aiConfig={aiConfig}
            onSaveAIConfig={handleUpdateAIConfig}
            chatMessages={chatMessages}
            onSendChat={handleSendChat}
            onClearChat={() => setChatMessages([])}
            onTriggerExplainArticle={handleExplainArticle}
            onTriggerJurisprudenceAI={handleSummarizeJurisprudence}
            quizQuestions={quizQuestions}
            quizParams={quizParams}
            onQuizParamsChange={setQuizParams}
            onGenerateQuiz={handleGenerateQuiz}
            onSelectQuizAnswer={handleSelectQuizAnswer}
            flashcards={flashcards}
            onChangeFlashcards={setFlashcards}
            flashcardParams={flashcardParams}
            onFlashcardParamsChange={setFlashcardParams}
            onGenerateFlashcards={handleGenerateFlashcards}
            editalMatches={editalMatches}
            onAnalyzeEdital={handleAnalyzeEdital}
            isLoadingAI={isLoadingAI}
            aiError={aiError}
            isPro={isPro}
            studyProgress={studyProgress}
            onUpdateStudyProgress={setStudyProgress}
            oabItems={oabItems}
            onOpenProDrawer={handleOpenProDrawer}
          />
        )}
      </div>

      {/* Peeking UI & Pro Plans Lateral Drawer */}
      <ProDrawerModal
        isOpen={proDrawerOpen}
        featureKey={proDrawerFeatureKey}
        appearance={appearance}
        authSession={authSession}
        isPro={isPro}
        isPcd={isPcd}
        onClose={() => setProDrawerOpen(false)}
        onAuthChange={refreshAuthAndPermissions}
        onPcdChange={(enabled) => {
          setIsPcd(enabled);
          const nextApp = { ...appearance, isPcdAudioAccess: enabled };
          setAppearance(nextApp);
          saveAppearanceSettings(nextApp);
        }}
      />

      {/* Law Cross-Reference Graph Modal (Opened via Hover Card on Inline Article Mentions) */}
      {showCrossRefModal && (
        <CrossReferenceGraphModal
          lawEpigraph={doc.epigraph}
          articles={doc.articles}
          graph={crossRefGraph}
          theme={appearance.theme}
          accentColor={currentAccent}
          initialArticle={crossRefModalArticle}
          onJumpToArticle={handleSelectArticleFromToc}
          onClose={() => setShowCrossRefModal(false)}
        />
      )}

      {/* Keyboard Shortcuts Modal */}
      {showShortcutsModal && (
        <ShortcutsModal
          isOpen={showShortcutsModal}
          onClose={() => setShowShortcutsModal(false)}
          appearance={appearance}
        />
      )}
    </div>
  );
};
