# Chrome Web Store Listing — Planalto Plus

> Last Updated: 2026-11-05  
> Version: 1.0.15  
> Package: `dist/planalto-moderno-chrome.zip`

---

## Changelog v1.0.15
• Resolução Completa de CSP para o VLibras: empacotamento local de script via `chrome-extension://` com regras declarativas (`declarativeNetRequest`) para contornar bloqueios de Content Security Policy na origem do Planalto, assegurando funcionamento fluido do intérprete 3D.
• Eliminação Definitiva da Sobreposição na Impressão (Ctrl+P): ocultação ativa e isolamento absoluto de todos os nós originais do DOM do Planalto durante a geração de PDF/impressão, impedindo sobreposição e acúmulo de parágrafos nas páginas geradas.
• Adaptação Fina de Tema: renderização do Tooltip da Chave de API e do botão selecionado do IA Chat estritamente sincronizada com a paleta ativa (Claro, Sépia ou Escuro).

## Changelog v1.0.14
• Correção da Paginação na Impressão e PDF: eliminação definitiva do acúmulo e sobreposição de textos entre páginas sucessivas ao imprimir com Ctrl+P.
• Widget do VLibras: carregamento resiliente via CDN oficial com botão flutuante discreto "X" para ocultação instantânea sem poluir o menu de aparência.
• Ajuste de Temas & Harmonia Visual: tooltip da Chave de API e botão ativo do IA Chat perfeitamente adaptados ao tema ativo (Claro, Sépia e Escuro).
• Aba Trilha & OAB Integrada ao Plano PRO: exibição do selo e trava de acesso PRO com convite contextual para conhecer recursos exclusivos.
• Redirecionamento da Página PRO: botão "Conhecer Planos" no drawer direciona para a página oficial completa de apresentação, mantendo o painel lateral minimalista e limpo.
• Acessibilidade PcD: simplificação da identificação da leitura por áudio gratuita sem menções burocráticas a siglas.

## Changelog v1.0.13
• Camada PRO, Autenticação Google OAuth & Magic Link (Supabase) com TTL offline de 24h e isolamento visual total para usuários gratuitos (Peeking UI Drawer).
• Acessibilidade Universal & Inclusão (Lei Federal nº 13.146/2015): integração do widget oficial do VLibras (com controle liga/desliga) e leitura por áudio 100% gratuita e ilimitada via Web Speech API nativa para pessoas com deficiência visual.
• Motor Dual de Áudio & Podcast Panorâmico da Lei Inteira (15 min): síntese de artigos e episódio panorâmico com Google Cloud TTS WaveNet (`pt-BR-Wavenet-B`), Gemini Flash (1M tokens) e Cache Global no Supabase Storage.
• Sincronização em Nuvem Local-First (`user_annotations` e `user_study_progress` com RLS `auth.uid()`).
• Analisador de Editais Multi-Legislações (PRO), Busca Semântica Ancorada ("Pergunte à Lei"), Trilha do Edital com `IntersectionObserver` e Mapeador de Incidência OAB/FGV (`oab_incidence.json`).

## Changelog v1.0.12
• Cache Local de Alta Capacidade com IndexedDB: armazenamento permanente e de latência zero para análises doutrinárias e panoramas de jurisprudência (STF/STJ) já consultados.
• Economia de Cotas e Tokens: artigos já explicados abrem instantaneamente (0ms e 0 tokens consumidos), mesmo sem conexão à internet.
• Painel de Controle de Cache: visualização do total de análises salvas e tamanho estimado em KB na aba Chave API, com opção de esvaziamento em 1 clique.

## Changelog v1.0.11
• Desmarcação Imediata ao Limpar a Busca: ao apagar os termos na barra de pesquisa superior ou no sumário (seja com backspace, seleção ou botão limpar), todos os destaques nos artigos são instantaneamente removidos e a norma retorna ao estado de leitura limpa.

## Changelog v1.0.10
• Contador de Resultados e Stepper na Barra Superior: indicador integrado `X de Y` e botões de navegação rápida `[↑]` e `[↓]` diretamente na barra de pesquisa superior, com suporte a `Enter` (próxima ocorrência) e `Shift + Enter` (ocorrência anterior).

## Changelog v1.0.9
• Ativação do Modal de Atalhos de Teclado: correção do botão no Sumário e tecla '?' para exibir o painel completo de atalhos rápidos de navegação.
• Correção de Sobreposição na Impressão e PDF: reestruturação completa da folha de estilos `@media print`, eliminando bloqueios de viewport, ocultando toolbars/tooltips flutuantes com `.no-print` e permitindo que artigos longos quebrem naturalmente entre as páginas A4 sem truncamento ou sobreposição de texto.
• Botão Direto de Imprimir / Salvar PDF: adicionado botão de 1 clique no menu de Aparência com atalho Ctrl+P para exportação limpa estilo livro jurídico.

## Changelog v1.0.8
• Busca Booleana Completa: suporte nativo a expressões exatas entre aspas `""`, operadores lógicos `OU` / `OR`, `E` / `AND` e negação `NÃO` / `NAO` / `NOT` / `-`.
• Destaque em Incisos e Subitens: correção do highlight de termos pesquisados em incisos, parágrafos, alíneas e penas, com tolerância total a acentos e flexões (singular/plural, gênero).
• Rastreamento e Rolagem ao Pressionar Enter: ao submeter a busca com Enter, a página rola suavemente até a primeira incidência do termo correspondente.
• Botão de Rolagem no Sumário (Stepper): navegação sequencial com botões [↑] e [↓] no sumário indicando o índice atual de correspondências (`1 de X`), permitindo alternar rapidamente entre todos os artigos encontrados.
• Dicionário Ampliado de Sinônimos Jurídicos: expansão com termos constitucionais brasileiros (ex.: `brasileiro` -> `nacional`, `cidadão`, `nato`, `naturalizado`, `povo`), com normalização morfológica.

## Changelog v1.0.7
• Ajuste Fino de Contraste no Highlight de Busca: cores adaptadas dinamicamente aos temas Claro, Sépia e Escuro, garantindo legibilidade perfeita e sem contraste lavado.

## Changelog v1.0.6
• Destaque Visual de Busca: termos pesquisados (e sinônimos) são automaticamente destacados com highlight no texto de cada artigo.

## Changelog v1.0.5
• Atalhos de Teclado Globais: navegação rápida 'J'/'K' (próximo/artigo anterior), '/' (busca), 'C' (texto compilado), '[' e ']' (painéis) e '?' (guia de atalhos).
• Botão de Atalhos no Sumário: acesso rápido ao modal de atalhos no rodapé da barra lateral esquerda.
• Estilização para Impressão e PDF (Ctrl+P): formatação limpa de livro jurídico, sem menus ou botões, com quebras de página otimizadas.

## Changelog v1.0.4
• Correção de layout e sobreposição de texto no botão Ocultar IA do menu de Aparência.

## Changelog v1.0.3
• Otimização de Memória RAM: purga ativa de dados de IA (chat, simulados e editais) ao ocultar IA, com persistência local em segundo plano.
• Aceleração de Renderização: suporte nativo a 'content-visibility: auto' nos artigos, poupando até 70% de processamento e RAM em leis extensas (ex.: Código Civil).
• Digitação Fluida a 60 FPS: transições com 'useDeferredValue' na busca do sumário e cabeçalho, eliminando microtravamentos ao pesquisar em grandes normas.

## Changelog v1.0.2
• Opção de Ocultar / Reativar recursos de IA centralizada exclusivamente no menu de Aparência.

## Changelog v1.0.1
• Ajuste de sobreposição (z-index) do menu de aparência e popover de remissões.
• Padronização da grafia ordinal dos artigos (LC 95/98: Art. 1º a 9º, e cardinal a partir do 10).
• Novo botão de cópia na íntegra de cada artigo ao lado do seu número.
• Busca superior com filtro exclusivo de artigos ao pressionar Enter/buscar e suporte a sinônimos jurídicos.
• Readequação da nota sobre sínteses automatizadas no assistente IA.
• Redução e refinamento tipográfico dos links de remissão no início da norma.

## 1. Store Listing Details

**Extension Name** [REQUIRED]  
`Planalto Plus — Leitura Jurídica & IA`  
*(40 caracteres — limite: 75)*

**Short Description** [REQUIRED] (Max 132 chars)  
`Moderniza o Planalto.gov.br com leitura limpa, sumário hierárquico, texto compilado, grifos, flashcards Anki e assistente de IA.`  
*(129 caracteres)*

**Detailed Description** [REQUIRED]  
Transforme sua experiência de estudo e consulta às leis brasileiras no Planalto.gov.br. O Planalto Plus substitui a visualização antiga por um leitor jurídico moderno, estruturado e livre de poluição visual.

Principais Recursos:

• Leitor Jurídico Estruturado: Converte leis, códigos e a Constituição em artigos, parágrafos e incisos claramente tipografados.  
• Modo Texto Compilado: Oculte dispositivos revogados com 1 clique e veja alertas sobre incisos alterados ou revogados.  
• Sumário Hierárquico Interativo: Navegue instantaneamente por Livros, Títulos, Capítulos e Artigos, ou busque por número e palavras-chave.  
• Caderno de Estudos Integrado: Faça anotações em cada artigo e organize grifos coloridos associados a tags ("OAB", "Concursos", "Importante").  
• Flashcards & Exportação Anki: Crie flashcards de estudo e exporte diretamente no formato nativo do Anki (.apkg), RemNote ou CSV.  
• Jurisprudência Rápida: Consulte decisões correlatas no STF, STJ e Jusbrasil com links contextuais diretos.  
• Inteligência Artificial sob Demanda: Conecte sua própria chave de API (Google Gemini, OpenAI, Claude ou Groq) para tirar dúvidas, resumir artigos e gerar simulados inéditos com gabarito comentado.  
• Acessibilidade & Conforto Visual: Temas Claro, Sépia e Escuro OLED, com controle de espaçamento e fontes hiperlegíveis (Atkinson Hyperlegible e OpenDyslexic).

Como Usar:
1. Instale a extensão no seu navegador.
2. Acesse qualquer lei ou código no portal oficial do Planalto (ex.: Constituição Federal, Código Civil, CLT, Código Penal).
3. A visualização moderna é ativada automaticamente, com sumário à esquerda, botões de estudo em cada artigo e alternância rápida para o texto original a qualquer momento.

Privacidade & Segurança:
• Suas anotações, grifos e chaves de API ficam gravadas exclusivamente na memória local do seu navegador.
• Nenhum dado pessoal, histórico ou informação de navegação é enviado a servidores externos de terceiros.

Suporte & Contato:
Tem dúvidas, sugestões ou solicitações? Envie seu feedback através do repositório no GitHub ou pelo canal de suporte oficial.

**Category** [REQUIRED]  
`Productivity` / `Productividade`

**Single Purpose** [REQUIRED]  
`Moderniza a leitura, anotação e estudo de legislações no portal Planalto.gov.br.`

**Primary Language** [REQUIRED]  
`Portuguese (Brazil)`

---

## 2. Graphics & Assets

| Asset | Dimensions | Status | Location / Reference |
|---|---|---|---|
| Store Icon [REQUIRED] | 128×128 PNG | ✅ Ready | `public/icons/icon-128.png` |
| Extension Icons | 16×16, 32×32, 48×48, 512×512 PNG | ✅ Ready | `public/icons/` |
| Screenshot 1 (Hero & Leitor) [REQUIRED] | 1280×800 PNG | ✅ Ready to capture | `chrome-store-slides.html` (Slide 1) |
| Screenshot 2 (Texto Compilado & Badges) | 1280×800 PNG | ✅ Ready to capture | `chrome-store-slides.html` (Slide 2) |
| Screenshot 3 (Sumário & Busca) | 1280×800 PNG | ✅ Ready to capture | `chrome-store-slides.html` (Slide 3) |
| Screenshot 4 (Grifos & Caderno) | 1280×800 PNG | ✅ Ready to capture | `chrome-store-slides.html` (Slide 4) |
| Screenshot 5 (IA & Doutrina) | 1280×800 PNG | ✅ Ready to capture | `chrome-store-slides.html` (Slide 5) |
| Screenshot 6 (Simulados & Edital) | 1280×800 PNG | ✅ Ready to capture | `chrome-store-slides.html` (Slide 6) |
| Small Promo Tile [RECOMMENDED] | 440×280 PNG | ⬜ Optional | Use slide banner from `chrome-store-slides.html` |
| Marquee Promo Tile | 1400×560 PNG | ⬜ Optional | Optional promo banner |

> **Dica para Captura de Screenshots:** O arquivo [`chrome-store-slides.html`](file:///c:/Users/T-GAMER/OneDrive/Documentos/Gemini/Planalto-Plus/chrome-store-slides.html) foi renderizado em 1280×800 px (padrão exato da Chrome Web Store). Abra-o no navegador e capture as telas dos slides 1 a 6.

---

## 3. Permissions Justification (Declaração para os Avaliadores)

Copie e cole estas justificativas exatas nos campos correspondentes no painel de desenvolvedores:

| Permissão | Tipo | Justificativa em Português | Justification in English |
|---|---|---|---|
| `storage` | `permissions` | Necessária para persistir localmente no navegador do usuário as configurações de aparência (tema, fonte), tags de grifos, anotações de estudo e a chave de API de IA do próprio usuário. | Required to persist user appearance settings (theme, font), custom highlight tags, study notes, and the user's BYOKey AI configuration locally. |
| `unlimitedStorage` | `permissions` | Necessária para assegurar que cadernos de estudo extensos, notas de artigos e transcrições de editais de concurso possam ser armazenados sem interrupções por limites de cota local ao estudar múltiplos códigos e leis federais. | Required to ensure that extensive law study notebooks, article notes, and concurso edital text can be stored offline across multiple large legal codes without quota eviction. |
| `*://*.planalto.gov.br/*` | `host_permissions` | Permite que o leitor moderno estruture páginas de leis federais, decretos, códigos e a Constituição no portal oficial da legislação brasileira. | Allows the modern reader to format and display federal law, decree, code, and constitution pages on the official Brazilian legislation portal. |
| `https://generativelanguage.googleapis.com/*` | `host_permissions` | Permite a conexão direta entre o navegador do usuário e o Google Gemini quando o usuário solicita explicação de artigos, resolução de questões ou análise de edital usando sua própria chave. | Allows direct communication between the user's browser and Google Gemini API when the user explicitly requests AI article explanations or quiz generation using their own API key. |
| `https://api.openai.com/*` | `host_permissions` | Permite a conexão direta entre o navegador e a API da OpenAI para usuários que optam por utilizar modelos OpenAI como provedor de IA. | Allows direct communication between the browser and OpenAI API for users choosing OpenAI as their AI provider. |
| `https://api.anthropic.com/*` | `host_permissions` | Permite a conexão direta entre o navegador e a API da Anthropic para usuários que optam pelo Claude como provedor de IA. | Allows direct communication between the browser and Anthropic API for users choosing Claude as their AI provider. |
| `https://openrouter.ai/*` | `host_permissions` | Permite a conexão direta entre o navegador e a API do OpenRouter para usuários que utilizam chaves e modelos do OpenRouter. | Allows direct communication between the browser and OpenRouter API for users configuring OpenRouter models. |
| `https://api.groq.com/*` | `host_permissions` | Permite a conexão direta entre o navegador e a API da Groq para inferência de alta velocidade com modelos Llama/Mixtral. | Allows direct communication between the browser and Groq API for high-speed inference with user-provided Groq keys. |
| `identity` | `permissions` | Permite login social seguro em 1 clique com Google OAuth (`chrome.identity.launchWebAuthFlow`) para sincronização opcional do caderno de estudos. | Enables secure 1-click Google OAuth login (`chrome.identity.launchWebAuthFlow`) for optional study notebook cloud sync. |
| `https://*.supabase.co/*` | `host_permissions` | Permite sincronização opcional em nuvem (Local-First) das anotações e progresso de estudo (`user_annotations` e `user_study_progress`), além de cache de áudio e podcast da lei para assinantes PRO. | Enables optional Local-First cloud synchronization of annotations and study progress, plus audio and law podcast caching for PRO subscribers. |
| `https://vlibras.gov.br/*` | `host_permissions` | Permite carregar o widget oficial de acessibilidade em Libras do Governo Federal (VLibras) para todos os usuários. | Allows loading the official Brazilian Federal Government Libras accessibility widget (VLibras) for all users. |

---

## 4. Privacy & Data Use Disclosure (Formulário de Privacidade da CWS)

### Declaração de Coleta de Dados:
* **A extensão coleta dados pessoais do usuário?**  
  **NÃO.** O Planalto Plus não coleta, não rastreia e não armazena dados de identificação pessoal, histórico de navegação nem endereços IP em nenhum servidor central.

### Respostas do Formulário da Chrome Web Store:
| Categoria de Dado | Coletado? | Transmitido para fora do dispositivo? | Finalidade | Compartilhado com Terceiros? |
|---|---|---|---|---|
| Informações Pessoais | Não | Não | — | Não |
| Informações Financeiras | Não | Não | — | Não |
| Informações de Saúde | Não | Não | — | Não |
| Credenciais / Autenticação | Não | Não | Chaves de API de IA do usuário são gravadas apenas localmente no `storage.local` e enviadas apenas para os provedores selecionados pelo usuário. | Não |
| Comunicações Pessoais | Não | Não | — | Não |
| Localização | Não | Não | — | Não |
| Histórico de Navegação | Não | Não | — | Não |
| Atividade do Usuário | Não | Não | — | Não |
| Conteúdo de Páginas Web | Sim (local) | Apenas sob demanda do usuário | O texto do artigo selecionado é enviado diretamente à API do provedor de IA escolhido pelo usuário para gerar o resumo/questão. | Apenas ao provedor de IA configurado pelo usuário no momento da requisição |

### Certificações Obrigatórias (Marcar todas com SIM no Dashboard):
- [x] O desenvolvedor garante que os dados do usuário NÃO são vendidos a terceiros.
- [x] O desenvolvedor garante que os dados do usuário NÃO são usados para fins não relacionados à funcionalidade principal da extensão.
- [x] O desenvolvedor garante que os dados do usuário NÃO são usados para determinar solvabilidade ou empréstimos.

---

## 5. Privacy Policy URL
Aponte o painel da loja para o documento público gerado em `PRIVACY.md` (hospedado no GitHub Pages, Gist público ou domínio próprio):
`https://[seu-usuario-github].github.io/[seu-repositorio]/PRIVACY.html` ou raw GitHub.

---

## 6. Pre-Submission Verification & Checklist

- [x] **Manifest V3**: 100% Manifest V3 sem APIs obsoletas.
- [x] **Package ZIP Limpo**: Gerado em `dist/planalto-plus-chrome.zip` (772 KB), sem `.git`, `node_modules`, arquivos de demo ou chunks órfãos.
- [x] **Ícones**: Dimensões 16, 32, 48, 128 e 512 px presentes e validados.
- [x] **Permissões Mínimas**: Sem `<all_urls>`, escopo restrito a `planalto.gov.br` e provedores de IA opcionais.
- [x] **Privacidade e Política**: Documento `PRIVACY.md` completo em PT-BR e EN.
- [x] **Material Promocional**: 6 slides 1280×800 em `chrome-store-slides.html`.

---

## 7. Version History

| Versão | Data | Mudanças | Status |
|---|---|---|---|
| 1.0.0 | 2026-11-04 | Release inicial: Leitor jurídico com Shadow DOM, sumário hierárquico, texto compilado, caderno de grifos, exportação Anki (.apkg), jurisprudência e assistente de IA BYOKey. | Pronto para Submissão |
